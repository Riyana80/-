<a href="index.php">Вернуться на сайт</a><br>
<?php 
    $HOST_DB 		= "localhost";	// Имя хоста
    $USER_DB 		= "g97884ps";		// Имя пользователя БД
    $PASSWORD_DB 	= "Admin1234";			// Пароль пользователя БД	
    $db = mysql_connect ($HOST_DB,$USER_DB,$PASSWORD_DB);		//запрос к базе данных

	if 	 (mysql_query("CREATE DATABASE IF NOT EXISTS `$base`")) echo  ("<p>База данных успешно создана!".PHP_EOL."</p>");
	else echo  ("<p>Ошибка создания базы данных: ".mysql_error().PHP_EOL."</p>");

	if (mysql_query("USE `$base`")) echo ("<p>База данных успешно подключена!".PHP_EOL."</p>");
    else echo ("<p>Ошибка подключения базы данных: ".mysql_error().PHP_EOL."</p>");

	$f = file_get_contents("_BASE/".$base.".sql");
	$f = str_replace("\n\n\n","\n\n",str_replace("\n\n\n","\n\n",str_replace("\n\n\n","\n\n",str_replace("\n\n\n","\n\n",$f))));
	$tables = explode("\n\n",$f);
	foreach($tables as $table) {
		echo $table.PHP_EOL;
		$result = mysql_query($table);
		if ($result) echo ("<p style='color:green;'>Запрос успешно выполнен!</p>");
		else 		 echo ("<p style='color:red;'>Ошибка выполнения запроса!</p>");
    }
	echo "<hr>";


?>
