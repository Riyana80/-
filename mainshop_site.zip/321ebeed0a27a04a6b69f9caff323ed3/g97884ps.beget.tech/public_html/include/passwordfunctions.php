<?php
function passwordForget($email)	{
if(empty($email)) $email = $_POST['email'];
// Отсылаем письмо
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";

$headers .= "From: GALAXY.RU<admin@galaxy.ru>\r\n";
$subject = "Восстановление пароля";
$pass = generateRandomString(10);
$md5pass = md5($pass);
$cont = "<b>Здравствуйте!<br>От Вас поступила заявка на восстановление пароля.</b><br><br>".
		"Ваш новый пароль ".$pass.
	"<hr>
	С уважением,<br>администратор";
// Отправляем письмо
	$sql = "SELECT email FROM user WHERE email = '".$email."'";
	$result = getMysqliResult($sql);
	if($result) $myrow = $result->fetch_assoc();
	if(!isset($myrow['email']))	{
		$_SESSION['error'] = "E-mail ".$email." не зарегистрирован в системе";
		return;
	}
	if (mail($email, $subject, $cont, $headers)) $_SESSION['success'] = "ВАША ЗАЯВКА НА ВОССТАНОВЛЕНИЕ ПАРОЛЯ ОТПРАВЛЕНА!";
	$sql = "UPDATE user SET password = '".$md5pass."' WHERE email = '".$email."'";
	$result = getMysqliResult($sql);
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function passwordForgetForm($error = "")	{ // Форма "Забыли пароль"
?>
<h1 class='text-center'>Восстановление пароля</h1>
<div class="row" style="margin-top:1	0px;">
	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>
	<div class="p-3 col-xs-10 col-sm-6 col-md-4 col-lg-4 reglog">
		<div class="close"><a href='admin.php'><span class="btnicon icon-close"></span></a></div>
		<form  data-toggle="validator" role="form" enctype="multipart/form-data"  name="loginform" action="admin.php" method="POST"class="m-3">
			  <div class="form-group row">
				<label for="inputEmail" class="control-Label col-lg-5 col-md-5 col-sm-5 col-xs-5">Email *</label>
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7"><input type="email" name = "email" class="form-control" id="inputEmail" placeholder="Email" required = "true"></div>
				<div class="help-block with-errors"></div>
			  </div>
			  <div class="text-center"><button type="submit" class="btn btn-primary">Восстановить</button></div>
			  <input name="rlaction" value="passwordForget" type="hidden" />
		</form>
	</div>
	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>
</div>
		</form>
	</div>
</div>
<?php   
}

?>