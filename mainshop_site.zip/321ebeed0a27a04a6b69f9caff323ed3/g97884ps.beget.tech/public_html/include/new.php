		<?php	
		$sql = "SELECT * FROM news WHERE id=".$_GET['id'];
		$result = getMysqliResult($sql);
		$new = $result->fetch_assoc();
		$size = getimagesize ($new['image']);
		$k = $size[0]/$size[1];
		$width = floor(250*$k);
		?>
		<div class="card px-2 mb-5">
		<h1><?php echo $new['name']; ?></h1>
			<div class="row">
				<div class="col-lg-5 col-md-6 col-sm-6 col-xs-12 text-center">
					<img style="height:250px; width:<?php echo $width;?>" src="<?php echo $new['image']; ?>" class=" mt-2" alt="">
				</div>
				<div class="col-lg-7 col-md-6 col-sm-6 col-xs-12">
					<?php echo nl2br($new['content']); ?>
				</div>
			</div>
		</div>
<?php 
