<?php
function index()	{
	$sql = "SELECT * FROM user WHERE id = ".$_SESSION['userid'];
	$result = getMysqliResult($sql);
	if($result) $user = $result->fetch_assoc();

?>
<h1 class="text-center" >Оформление заказа</h1>
<div style="margin-bottom:70px;" class="mt-2 container-fluid">
<div class="row">
	<div class="col-lg-3 col-md-2 col-sm-1"></div>
	<div class="col-lg-6 col-md-8 col-sm-10 bg-light p-2">
		<form enctype='multipart/form-data' action='?page=order' method='post'>
		  <h3 class="text-center bg-info text-light p-2" >Заказчик</h3>
		  <div class="form-group">
			<label>ФИО *</label>
			<input type="text" name = "fio" required="true" class="form-control" value = "<?php echo $user['lastname'].' '.$user['firstname'].' '.$user['fname']; ?>" placeholder="Введите Ваше ФИО">
		  </div>
		  <div class="form-group">
			<label>Контактный телефон *</label>
			<input type="phone" name = "phone"  required="true" class="form-control" value = "<?php echo $user['phone']; ?>" placeholder="Введите Ваш контактный телефон">
		  </div>
		  <div class="form-group">
			<label>Электронная почта *</label>
			<input type="email" name = "email" class="form-control"  required="true"  value = "<?php echo $user['email']; ?>" placeholder="Введите email">
		  </div>
		  <div class="form-group">
			<label class="w-100">Дополнительно</label>
			<small>Комментарии к заказу</small>
			<textarea name="comment" class="form-control" rows="3"></textarea>
		  </div>
		  <div class="w-100 text-center">
			  <button type="submit" class="btn btn-primary">Оформить</button></div>
		  <input type='hidden' name='action' value = 'insert'>
		  <hr><span class='text-red font-weight-bold'>*</span> - обязательные для заполнения поля
		</form>
	</div>
	<div class="col-lg-3 col-md-2 col-sm-1"></div>
</div>
</div>
<?php }

function insert()	{
	$sql = "INSERT INTO `order` (`user_id`, `comment`, `orderstatus_id`) VALUES (".userID().",'".$_POST['comment']."',1)";
	$result = getMysqliResult($sql);
	if(!$result) {
		echo "<div class='text-center text-danger mt-5'>Ошибка оформления заказа.</div>";
		return;
	}
	$lastinsertid = lastInsertId();
	if($result) echo "<div class='text-center text-info mt-5'>Ваш заказ успешно оформлен. Наши менеджеры свяжутся с Вами в ближайшее время.</div>";
 	$sql1 = "SELECT * FROM cart WHERE user_id=".$_SESSION['userid']." GROUP BY product_id";
	$result1 = getMysqliResult($sql1);
	if($result1) while($cart = $result1->fetch_assoc())	{ 
		$sql2 = "INSERT INTO `order_product` (`product_id`, `order_id`, `kol`) VALUES (".$cart['product_id'].",".$lastinsertid.",".$cart['kol'].")";
		$result2 = getMysqliResult($sql2);
	}	
 	$sql3 = "DELETE FROM cart WHERE user_id=".$_SESSION['userid'];
	$result3 = getMysqliResult($sql3);
}

