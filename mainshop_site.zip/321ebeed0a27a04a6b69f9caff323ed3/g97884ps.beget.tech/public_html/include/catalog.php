<?php
if(!empty($_GET['category'])) $parent = $_GET['category']; else $parent = 1;
getBreadcrumbs('category',$parent);
?>
<div class="row m-2 mb-5">
<?php
$sql = "SELECT * FROM category WHERE parent_id = $parent";
$result = getMysqliResult($sql);
while($cat = $result->fetch_assoc())	{
	?>
	<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 p-1">
		<div class="card px-2">
			<img src="<?php echo $cat['image'];?>" class="card-img-top mt-2" title="<?php echo $cat['name']; ?>" alt="<?php echo $cat['name']; ?>">
			<div class="card-body category">
				<h5 class="card-title text-center text-primary"><a href="?page=catalog&category=<?php echo $cat['id']; ?>"><?php echo $cat['name']; ?></a></h5>
			</div>
		</div>
	</div>
<?php } 
$sql = "SELECT * FROM product WHERE category_id = $parent";
$result = getMysqliResult($sql);
while($prod = $result->fetch_assoc())	{
		$size = getimagesize ($prod['image']);
		$k = $size[0]/$size[1];
		$width = floor(250*$k);
	?>
	<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 p-1">
		<div class="card px-4 pb-5">
			<img style="height:250px; width:<?php echo $width;?>px" src="<?php echo $prod['image'];?>" class="mx-auto  mt-2" title="<?php echo $prod['name']; ?>" alt="<?php echo $prod['name']; ?>">
			<div class="card-body category">
				<h5 style="height:48px; overflow:hidden;" class="card-title text-center text-primary"><a href="?page=product&id=<?php echo $prod['id']; ?>"><?php echo $prod['name']; ?></a></h5>
				<h5 class="card-title text-center text-success"><?php echo $prod['price']; ?> руб.</h5>
			</div>
		</div>
	</div>
<?php } ?>
</div>
