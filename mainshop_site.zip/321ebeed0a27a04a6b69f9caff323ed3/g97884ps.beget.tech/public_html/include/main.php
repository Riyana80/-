<?php 
	$sql = "SELECT P.* FROM slide S, product P WHERE S.product_id = P.id";
	$result = getMysqliResult($sql);
	$arr = array();
	if ($result->num_rows > 0) 
		while($slide = $result->fetch_assoc())	$arr[] = $slide;
?>
          
<div class="row p-3">
	<div style='text-align:justify' class='col-lg-6 col-md-6 col-sm-12 col-xs-12'>
	<?php
		$content = file_get_contents("include/about.php");
		$content = substr($content,0,strpos($content,"</p>")+4);
		echo $content;
		echo "<div class='text-right'><button class='btn btn-primary mx-auto'><a class='text-white'  href='?page=about'>Подробнее...</a></button></div>";
	?>
	</div>
	<div class='col-lg-6 col-md-6 col-sm-12 col-xs-12'> <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
		<h1 class="text-primary text-center mt-2">Акции:</h1>
		<ol class="carousel-indicators">
			<?php 
				foreach($arr as $key=>$a)	
					echo '<li data-target="#carouselExampleCaptions" data-slide-to="'.$key.'" class="active"></li>';
			?>
		</ol>
		<div class="carousel-inner">
			<?php foreach($arr as $key=>$a)	{
			$size = getimagesize ($a['image']);
			$k = $size[0]/$size[1];
			$width = floor(180*$k);
			
			?>

				  <div class="carousel-item <?php if($key==0) echo 'active';?>">
					<div class="carousel-caption d-none d-md-block">
					  <h5 class="text-primary"><?php echo $a['name']; ?></h5>
					</div>
						<a href="?page=product&id=<?php echo $a['id']; ?>">
							<img style="margin-bottom:120px;height:180px; width:<?php echo $width; ?>px" src="<?php echo $a['image']; ?>" class="d-block mx-auto" alt="...">
						</a>
				  </div>

			<?php } ?>
		</div>
		<a style="font-size:30px; font-weight:bold;" class="text-primary carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
		  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
		  <span class="sr-only">Previous</span><
		</a>
		<a style="font-size:30px" class="text-primary carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
		  <span class="carousel-control-next-icon" aria-hidden="true"></span>
		  <span class="sr-only">Next</span>>
		</a>
	  </div>
	  </div>
  </div>
<h3 class="text-primary text-center mt-2">Последние поступления:</h3>
<div class="row m-2 mb-5">
<?php
$sql = "SELECT * FROM product WHERE 1 ORDER BY id DESC LIMIT 0,4";
$result = getMysqliResult($sql);
while($prod = $result->fetch_assoc())	{
		$size = getimagesize ($prod['image']);
		$k = $size[0]/$size[1];
		$width = floor(250*$k);
	?>
	<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 p-1">
		<div class="card px-4 pb-5">
			<img style="height:250px; width:<?php echo $width;?>px" src="<?php echo $prod['image'];?>" class="mx-auto mt-2" title="<?php echo $prod['name']; ?>" alt="<?php echo $prod['name']; ?>">
			<div class="card-body category">
				<h5 style="height:48px; overflow:hidden;" class="card-title text-center text-primary"><a href="?page=product&id=<?php echo $prod['id']; ?>"><?php echo $prod['name']; ?></a></h5>
				<h5 class="card-title text-center text-success"><?php echo $prod['price']; ?> руб.</h5>
			</div>
		</div>
	</div>
<?php } ?>
</div>
<h3 class="text-primary text-center mt-2">Скоро в продаже:</h3>
<div class="row m-2 mb-5">
<?php
$sql = "SELECT * FROM news WHERE 1 ORDER BY id DESC LIMIT 0,3";
$result = getMysqliResult($sql);
while($new = $result->fetch_assoc())	{
	?>
	<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 p-1">
		<div class="card px-4">
			<img style="" src="<?php echo $new['image'];?>" class="mx-auto mt-2 card-img-top" title="<?php echo $new['name']; ?>" alt="<?php echo $new['name']; ?>">
			<div class="card-body category">
				<h5 style="height:48px; overflow:hidden;" class="card-title text-center text-primary"><a href="?page=new&id=<?php echo $new['id']; ?>"><?php echo $new['name']; ?></a></h5>
			</div>
		</div>
	</div>
<?php } ?>
</div>
