<?php
function index()	{
?>
			<script>
				function confirmSpelll() {
				if (confirm("Вы действительно хотите удалить этот товар из корзины?")) return true;
				else return false;
				}
			</script>
<h1 class="ml-4">Корзина</h1>
<?php 
		$sql = "SELECT * FROM cart WHERE user_id=".$_SESSION['userid']." GROUP BY product_id";
		$result = getMysqliResult($sql);
		if($result->num_rows==0) {
			echo "<h4 class='text-info text-center'>Корзина пуста</h4>";
			return;
		}
?>
<div style="margin-bottom:60px;" class="container-fluid text-center">
	<div class="row bg-info mx-auto w-75 ">
		<div class="col-lg-2 col-md-2 col-sm-12 text-center border border-dark p-2 d-none d-md-block">Фото</div>
		<div class="col-lg-2 col-md-2 col-sm-12 text-center border border-dark p-2 d-none d-md-block">Название</div>
		<div class="col-lg-2 col-md-2 col-sm-12 text-center border border-dark p-2 d-none d-md-block">Кол-во</div>
		<div class="col-lg-2 col-md-2 col-sm-12 text-center border border-dark p-2 d-none d-md-block">Цена</div>
		<div class="col-lg-2 col-md-2 col-sm-12 text-center border border-dark p-2 d-none d-md-block">Итого</div>
		<div class="col-lg-2 col-md-2 col-sm-12 text-center border border-dark p-2 d-none d-md-block">Действия</div>
	</div>
<?php
		if($result) while($cart = $result->fetch_assoc())	{
						$sql1 = "SELECT * FROM product WHERE id=".$cart['product_id'];
						$result1 = getMysqliResult($sql1);
						$product = $result1->fetch_assoc();
?>
	<div class="row bg-white mx-auto w-75">
		<div class="col-6  col-lg-2 col-md-2 col-sm-6  text-center  border border-dark p-2">
			<img width="100" src="<?php echo $product['image']; ?>" alt="">
		</div>
		<div class="col-6  col-lg-2 col-md-2 col-sm-6  text-center  border border-dark p-2 pt-4"><?php echo $product['name']; ?></div>
		<div class="col-6  col-lg-2 col-md-2 col-sm-6  text-center  border border-dark p-2 pt-4"><input disabled="true" style="background-color:white;" class="form-control" type="number" placeholder="Кол-во"  value="<?php echo $cart['kol']; ?>"></div>
		<div class="col-6  col-lg-2 col-md-2 col-sm-6  text-center  border border-dark p-2 pt-4"><?php echo $product['price']; ?></div>
		<div class="col-6  col-lg-2 col-md-2 col-sm-6  text-center  border border-dark p-2 pt-4"><?php echo $product['price']*$cart['kol']; ?></div>
		<div class="col-12 col-lg-2 col-md-2 col-sm-12 text-center border border-dark p-2 pt-4">
			<a href="?page=cart&action=updateForm&id=<?php echo $cart['id']; ?>"><img width="16" class="m-1" title="Редактировать" src="images/edit.png"></a>
			<a  onclick='return confirmSpelll();' href="?page=cart&action=delete&id=<?php echo $cart['id']; ?>"><img  width="16"  title="Удалить" class="m-1" src="images/del.png"></a>
		</div>
	</div>
<?php } ?>
	<button class="mx-auto btn btn-primary px-5 mt-3"><a href="?page=order" class="card-link text-light">Оформить заказ</a></button>
</div>
<?php 
} 
    // Обновления записи (форма)
     function updateform($id = NULL){
		if(!empty($id))	{
			$sql = "SELECT * FROM cart WHERE id=".$id;
			$result = getMysqliResult($sql);
		if($result)
			$cart = $result->fetch_assoc();
		}
		else {
			$fields = "id,user_id,product_id,kol";
			foreach(explode(",",$fields) as $f) $cart[$f] = '';
		}
		echo "<h1 class='text-center' >Изменение количества товара</h1></center>".PHP_EOL;
		echo "<div class='row'>".PHP_EOL;
		echo '	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>'.PHP_EOL;
		echo '	<div class="p-3 col-xs-10 col-sm-6 col-md-4 col-lg-4" style="margin:10px auto 20px auto; padding:5px 10px; border:1px solid #ddd; border-radius:10px;">'.PHP_EOL;
		echo '		<div style="position:relative;width:100%; text-align:right; float:right;right:-13px;">'.PHP_EOL;
		echo '			<a href="admin.php"><span style="color:grey; font-size:20px" class="btnicon icon-close"></span></a>'.PHP_EOL;
		echo '		</div>'.PHP_EOL;
		echo "		<form enctype='multipart/form-data' action='?page=cart' method='post'>".PHP_EOL;
		echo "			<input type='hidden' name='id' value = '".$id."'>".PHP_EOL;
		?>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Количество</label>
			<div>
				<input class='form-control' id='kol' name='kol' type='number' value='<?php echo $cart['kol']; ?>'/>
			</div>
		</div>

<?php
		if(!empty($id)) echo "			<input type='hidden' name='action' value = 'update'>".PHP_EOL;
		else echo "			<input type='hidden' name='action' value = 'insert'>".PHP_EOL;
		echo "			<input type='hidden' name='table' value = 'cart'>".PHP_EOL;
		echo "			<input type='hidden' name='page' value = 'cart'>".PHP_EOL;
		if(!empty($id)) echo '			<div class="text-center"><input class="submit" id="Submit" value="Сохранить изменения" type="submit" name="Submit" ></div>'.PHP_EOL;
		else echo '			<div class="text-center"><input class="submit" id="Submit" value="Добавить" type="submit" name="Submit" ></div>'.PHP_EOL;
		echo "		</form>".PHP_EOL;
		echo "	</div>".PHP_EOL;
		echo '	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>'.PHP_EOL;
		echo "</div>".PHP_EOL;
	}

// Обновление записи
 	function update()	{
		$post = $_POST;
		$files = $_FILES;
		if (!empty($files))	{
			$uploaddir = 'uploads/';
			foreach($files as $ki=>$f)	{
				$var = $ki."name";
				$arr = explode(".",basename($files[$ki]['name']));
				$end = end($arr);
				$uploadfile  = $uploaddir . str_replace("-".$end,".".$end,str2url(basename($files[$ki]['name'])));
				if (basename($files[$ki]['name'])) 	{
					move_uploaded_file($files[$ki]['tmp_name'] , $uploadfile);
					$post[$ki] = $uploadfile;
				} 	else $post[$ki] = $post[$var];

					unset($post[$var]);
			}
		}
			$table = $post['table'];
			$id = $post['id'];
			unset($post['Submit'],$post['action'],$post['page'],$post['table'],$post['id']);
			$values = array();
			foreach($post as $key=>$val) $values[] = $key." = '".$val."'";
			$sql = "UPDATE cart SET ".implode(",",$values)." WHERE id=".$id;
			$result = getMysqliResult($sql);
			index();
	}

	function delete()	{
		$id = 		$_GET['id'];
		$sql = "DELETE FROM cart WHERE id=".$id;
		$result = getMysqliResult($sql);
		index();
	}
	
     // Добавления записи (форма)
    function insertform(){
		updateform();
	}


 
?>