		<?php	
		if(!empty($_GET['cart'])) {
			$id = $_GET['cart']; 
		}
		else $id = $_GET['id'];
		getBreadCrumbs('product',$id);	
		$sql = "SELECT * FROM product WHERE id=".$id;
		$result = getMysqliResult($sql);
		if($result->num_rows>0) {
			$prod = $result->fetch_assoc();
		}
		$size = getimagesize ($prod['image']);
		$k = $size[0]/$size[1];
		$width = floor(250*$k);
		?>
		<div class="card px-2 mb-2">
		<h1><?php echo $prod['name']; ?></h1>
			<div class="row">
				<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 text-center">
					<img style="height:250px; width:<?php echo $width;?>" src="<?php echo $prod['image']; ?>" class=" mt-2" alt="">
					<h5 class="card-title text-center text-success mt-2"><?php echo $prod['price']; ?> руб.</h5>
					<?php if(is_user()) { ?>
					<a href="?page=product&cart=<?php echo $prod['id']; ?>" class="card-link text-light"><button class="btn btn-primary px-5 my-3 ">В корзину</button></a>
					<?php } 
					elseif(!is_admin()&&!is_manager()) echo '<div class="w-100 text-info text-center">Авторизуйтесь для совершения покупок</div>';?>
					<?php if((!empty($_GET['cart']))&&(toCart($id))) echo '<div class="w-100 text-success text-center">Товар добавлен в корзину</div>'; ?>
				</div>
				<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
					<?php echo str_replace(array('Параметры','Описание','Характеристики'),array('<b>Параметры</b>','<b>Описание</b>','<b>Характеристики</b>'),nl2br($prod['description'])); ?>
				</div>
			</div>
		</div>
<?php 
if(!empty($_POST))	insertRequest();
if(is_user()) insertRequestForm($id);	
	

printProductQueries($id);
// Возвращает отзывы о товаре
function printProductQueries($id = 0)	{	// Функция вывода отзывов
	if(($id == 0)&&(is_user())) query_form($id);
	$query = "SELECT * FROM request WHERE product_id = ".$id." ORDER BY ID DESC";
	$result = getMysqliResult($query);
	if($result->num_rows == 0) return;
		echo "<h3 class='px-3 text-primary'>Отзывы о товаре</h3>";
		echo "<div class='mb-5'>";
		while ($request = $result->fetch_assoc()) {
			echo "<div class='p-2 border'>";
			echo "<p>".ratingName($request['rating_id'])."</p>";
			echo "<p>".$request['content']."</p>";
			echo "<p class='font-weight-bold'>".userFirstName($request['user_id']).", ".date("d/m/Y", strtotime($request['date']))."</p>";
			echo "</div>";
		}
		echo "</div>";
}

function toCart($product)	{				// Помещает товар в корзину
		$sql = "INSERT INTO cart (product_id,user_id,kol) VALUES (".$product.",".$_SESSION['userid'].",1)";
		$result = getMysqliResult($sql);
		if($result) return true;
}

function productName($id)	{				// Функция возвращает имя товара
	$query = "SELECT * FROM product WHERE id=".$id;
	$result = getMysqliResult($query);
	$myrow = $result->fetch_assoc();
	return $myrow['name'];
}

function ratingName($id)	{				// Функция возвращает имя товара
	$query = "SELECT * FROM rating WHERE id=".$id;
	$result = getMysqliResult($query);
	$myrow = $result->fetch_assoc();
	return $myrow['name'];
}

function userFirstName($user) {				// Возвращает логин пользователя по его коду
	$query = "SELECT * FROM user WHERE ID='".$user."'";
	$result = getMysqliResult($query);
	$myrow = $result->fetch_assoc();
	return $myrow['firstname'];
}

   	// Функция формы ввода для добаления записи в таблицу
    function insertRequestForm($product_id){
?>
		<h3 class="text-center text-primary">Добавление отзыва о товаре</h3>
		<div class='row margin-bottom-50 mx-3'>
			<div class="col-xs-1 col-sm-2 col-md-2 col-lg-3"></div>
			<div class="p-4 col-xs-10 col-sm-8 col-md-8 col-lg-6 shadow-lg border rounded">
				<div style="position:relative;width:100%; text-align:right; float:right;right:-13px;">
					<a href="admin.php?table=request"><span style="color:grey; font-size:20px" class="btnicon icon-close"></span></a>
				</div>
				<form enctype='multipart/form-data' action='?page=product&id=<?php echo $product_id; ?>' method='post'>
					<div class='form-group row w-100'>
						<label class='col-lg-12 col-md-12 col-sm-12 col-xs-12 font-weight-bold' style='word-wrap: break-word;'>Содержимое</label>
						<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-2' >
							<textarea name='content' class='form-control' cols='100' rows='5'><?php echo $item['content']; ?></textarea>
						</div>
					</div>
					<div class='form-group row w-100'>
						<label class=' font-weight-bold col-lg-5 col-md-5 col-sm-12 col-xs-12' style='word-wrap: break-word;'>Рейтинг *</label>
						<div class='col-lg-7 col-md-7 col-sm-12 col-xs-12' >
<?php echo getInsertSelect(); ?>
						</div>
					</div>
					<input type='hidden' 	name='product_id' 	value = '<?php echo $product_id; ?>'>
					<input type='hidden' 	name='user_id' 	value = '<?php echo $_SESSION['userId']; ?>'>
					<input type='hidden' 	name='action' 	value = 'insert'>
					<input type='hidden' 	name='table' 	value = 'request'>
					<input type='hidden' 	name='date' 	value = '<?php echo date("Y-m-d");?>'>
					<input type='hidden' 	name='id' 		value = '<?php echo $id; ?>'>
					<div class="text-center">
						<input style="width:200px;" class="submit btn btn-primary form-control mt-2" id="Submit" value="Добавить" type="submit" name="Submit" >
					</div>
					<span class='text-red font-weight-bold'>*</span> - обязательные для заполнения поля
				</form>
			</div>
			<div class="col-xs-1 col-sm-1 col-md-2 col-lg-3"></div>
		</div>
<?php	}

	// Функция выдачи select-списка для формы добавления
	function getInsertSelect()	{
?>
							<select  name="rating_id" required="true" class="form-control">
<?php
				$sql = "SELECT * FROM rating WHERE 1 ORDER BY name";
				$result = getMysqliResult($sql);
				if($result->num_rows > 0) while($option = $result->fetch_assoc())	{ 
?>
								<option value="<?php echo $option['id']; ?>"><?php echo $option['lname']; ?></option>
<?php			} ?>
							</select>
<?php
	}
	
	// Функция добавляет запись в таблицу
 	function insertRequest()	{
		$post = $_POST;
		$table = $post['table'];
		$id = $post['id'];
		unset($post['Submit'],$post['action'],$post['table'],$post['id']);
		
		$values = "'".implode("','",array_values($post))."'";
		$keys = implode(",",array_keys($post));
		$sql = "INSERT INTO request (".$keys.") VALUES (".$values.")";
		$result = getMysqliResult($sql);
	}
	
