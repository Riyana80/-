<?php
function getSearchBreadCrumbs($value)	{
?>
	<nav style="background:#edecef;" aria-label="breadcrumb">
		<div class="row">
			<div class="col-lg-9 col-md-7 col-sm-6">
			  <ol class="breadcrumb">
				<li class="breadcrumb-item">Результаты поиcка для: <?php echo $value; ?></li>
			  </ol>
			</div>
			<div class="col-lg-3 col-md-5 col-sm-6 pt-2">
				<form method="post" action="index.php" class="form-inline my-2">
						<input class="form-control mr-sm-2" name = "value" type="search" placeholder="Поиск" aria-label="Поиск">
						<input type="hidden" name="page" value="search">	
						<button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Найти</button>
				</form>
			</div>	
	</nav>
<?php
}
getSearchBreadCrumbs($_POST['value']);

?>
<div class="row m-2 mb-5">
<?php
		if(!empty($_POST['value']))	{
			$sql = "SELECT * FROM product WHERE name LIKE '%".$_POST['value']."%'";
			$result = getMysqliResult($sql);
			if($result->num_rows == 0)	echo "<p style='color:red; font-size:20px;' class='text-center w-100'>По заданному поисковому запросу ничего не найдено!</p>";
			if($result) {
				while($prod = $result->fetch_assoc()) {
						$size = getimagesize ($prod['image']);
						$k = $size[0]/$size[1];
						$width = floor(250*$k);
					?>
					<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 p-1">
						<div class="card px-4 pb-5">
							<img style="height:250px; width:<?php echo $width;?>px" src="<?php echo $prod['image'];?>" class="mx-auto  mt-2" title="<?php echo $prod['name']; ?>" alt="<?php echo $prod['name']; ?>">
							<div class="card-body category">
								<h5 style="height:48px; overflow:hidden;" class="card-title text-center text-primary"><a href="?page=product&id=<?php echo $prod['id']; ?>"><?php echo $prod['name']; ?></a></h5>
								<h5 class="card-title text-center text-success"><?php echo $prod['price']; ?> руб.</h5>
							</div>
						</div>
					</div>
				<?php 
				}
			}		
		}
?>
</div>
