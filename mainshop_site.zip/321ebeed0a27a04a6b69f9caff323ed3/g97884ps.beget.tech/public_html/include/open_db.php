<?php
class DBi {
    public static $conn;
}
DBi::$conn = new mysqli('localhost', 'g97884ps_main', 'Admin1234', $base);
if (DBi::$conn->connect_errno) {
    echo "Ошибка: <strong>Не удалось создать соединение с базой MySQL и вот почему: </strong><br>";
    echo "Номер ошибки: <strong>" . DBi::$conn->connect_errno . "</strong><br>";
    echo "Ошибка: <strong>" . DBi::$conn->connect_error . "</strong><br><hr>";
	include("init.php");
    exit;
}

function getMysqliResult($sql)	{
	$conn = DBi::$conn;
	$result = $conn->query($sql);
	return $result;
}

function lastInsertId()	{
	$conn = DBi::$conn;
	return $conn->insert_id;
}

?>