<?php
// =============== ПОЛЬЗОВАТЕЛИ ==================

function userID($user=NULL)	{					// Возвращает код пользователя по логину

	$sql = "SELECT * FROM user WHERE email='".$user."'";
	$result = getMysqliResult($sql);
	if ($result->num_rows > 0) {
		$myrow = $result->fetch_assoc(); 
		return $myrow['id'];
	}
	else return (isset($_SESSION['userid']))?$_SESSION['userid']:'';
}

function userName($user) {					// Возвращает логин пользователя по его коду
	$sql = "SELECT * FROM user WHERE ID='".$user."'";
	$result = getMysqliResult($sql);
	if ($result) {
		$myrow = $result->fetch_assoc(); 
		return $myrow['email'];
	}
	return '';
}

// Функция проверки пользователя на статус администратора
function is_admin() { 						
	$flag = false;
	$user=$_SESSION['userName']; 
	if(empty($user)) $user = $_SESSION['email'];
	if (!empty($user)) {
		$sql = "SELECT * FROM user WHERE email='".$user."'";
		$result = getMysqliResult($sql); 
		if (!$result) return false;
		$myrow  = $result->fetch_assoc(); 
		if ($myrow['userstatus_id']=='1') $flag = true;
	}
	return $flag;	  
}

// Функция проверки пользователя на статус менеджера
function is_manager() { 						
	$flag = false;
	$user=$_SESSION['userName']; 
	if(empty($user)) $user = $_SESSION['email'];
	if (!empty($user)) {
		$sql = "SELECT * FROM user WHERE email='".$user."'";
		$result = getMysqliResult($sql); 
		if (!$result) return false;
		$myrow  = $result->fetch_assoc(); 
		if ($myrow['userstatus_id']=='3') $flag = true;
	}
	return $flag;	  
}

// Функция проверки пользователя на статус пользователя
function is_user() { 						
	$flag = false;
	$user=$_SESSION['userName']; 
	if(empty($user)) $user = $_SESSION['email'];
	if (!empty($user)) {
		$sql = "SELECT * FROM user WHERE email='".$user."'";
		$result = getMysqliResult($sql); 
		if (!$result) return false;
		$myrow  = $result->fetch_assoc(); 
		if ($myrow['userstatus_id']=='2') $flag = true;
	}
	return $flag;	  
}

