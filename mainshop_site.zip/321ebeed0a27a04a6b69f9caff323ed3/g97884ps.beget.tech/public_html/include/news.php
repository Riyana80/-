<h1>Новинки</h1>
<div class="row m-2 mb-5">
<?php
if (empty($_GET['p'])) $limit = "0,10";
else $limit = (string)($_GET['p']*10).",10";
$sql = "SELECT * FROM news WHERE 1 ORDER BY id DESC LIMIT ".$limit;
$result = getMysqliResult($sql);
while($new = $result->fetch_assoc())	{
	?>
	<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 p-1">
		<div class="card px-4">
			<img style="" src="<?php echo $new['image'];?>" class="mx-auto mt-2 card-img-top" title="<?php echo $new['name']; ?>" alt="<?php echo $new['name']; ?>">
			<div class="card-body category">
				<h5 style="height:48px; overflow:hidden;" class="card-title text-center text-primary"><a href="?page=new&id=<?php echo $new['id']; ?>"><?php echo $new['name']; ?></a></h5>
			</div>
		</div>
	</div>
<?php } ?>
</div>
<?php 
$sql = "SELECT COUNT(*) as count FROM news WHERE 1 ORDER BY id DESC";
$result = getMysqliResult($sql);
$count = $result->fetch_assoc();
$count = $count['count'];
echo "<div class='row px-5'>";
$i = 0;
while($i*10 < $count) { echo "<div class='col text-center font-weight-bold'><a href='?page=news&p=".$i."'>< ".(string)($i+1)." - ".(string)($i+10)." ></a></div>"; $i++; }
echo "</div>";

