<?php
function left($str = "", $count)		{
	return substr($str, 0, $count);
}

function right($str = "", $count)		{
	return substr($str, $count*-1);
}

function pr($str)	{
	echo "<pre>";
	if((is_array($str))||(is_object($str))) print_r($str);
	else echo $str;
	echo "</pre>";
}

function getBreadcrumbs($table,$id)	{
	$bc = array();
	
	if ($table == 'product')	{
			$sql = "SELECT id, name, category_id FROM product WHERE id=$id";
			$result = getMysqliResult($sql);
			if($result->num_rows>0) {
				$myrow = $result->fetch_assoc();
				$bc['self'] = $myrow['name'];
				$id = $myrow['category_id'];
			}
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$id;
			$result = getMysqliResult($sql);
			if($result->num_rows>0) {
				$myrow = $result->fetch_assoc();
				$bc['parent3'] 	= $myrow['name'];
				$bc['id3']		= $myrow['id'];
				$id = $myrow['id'];
			}
		}	
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$myrow['parent_id'];
			$result = getMysqliResult($sql);
			if($result->num_rows>0) {
				$myrow = $result->fetch_assoc();
				$bc['parent2'] 	= $myrow['name'];
				$bc['id2']		= $myrow['id'];
				$id = $myrow['id'];
			}
		}	
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$myrow['parent_id'];
			$result = getMysqliResult($sql);
			if($result->num_rows>0) {
				$myrow = $result->fetch_assoc();
				$bc['parent1'] 	= $myrow['name'];
				$bc['id1']		= $myrow['id'];
				$id = $myrow['id'];
			}
		}
	}
	if ($table == 'category')	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=$id";
			$result = getMysqliResult($sql);
			$myrow = $result->fetch_assoc();
			$bc['self'] = $myrow['name'];
			$id = $myrow['id'];
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$myrow['parent_id'];
			$result = getMysqliResult($sql);
			$myrow = $result->fetch_assoc();
			$bc['parent3'] 	= $myrow['name'];
			$bc['id3']		= $myrow['id'];
			$id = $myrow['id'];
		}	
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$myrow['parent_id'];
			$result = getMysqliResult($sql);
			$myrow = $result->fetch_assoc();
			$bc['parent2'] 	= $myrow['name'];
			$bc['id2']		= $myrow['id'];
			$id = $myrow['id'];
		}	
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$myrow['parent_id'];
			$result = getMysqliResult($sql);
			$myrow = $result->fetch_assoc();
			$bc['parent1'] 	= $myrow['name'];
			$bc['id1']		= $myrow['id'];
			$id = $myrow['id'];
		}
	}
	?>
	<nav style="background:#edecef;" aria-label="breadcrumb">
		<div class="row">
			<div class="col-lg-9 col-md-7 col-sm-6">
			  <ol class="breadcrumb">
				<?php 
				if(!in_array("Каталог", $bc)) 	echo '<li class="breadcrumb-item"><a href="?page=catalog&category=1">Каталог</a></li>';
				if(!empty($bc['parent1'])) 		echo '<li class="breadcrumb-item"><a href="?page=catalog&category='.$bc['id1'].'">'.$bc['parent1'].'</a></li>';
				if(!empty($bc['parent2'])) 		echo '<li class="breadcrumb-item"><a href="?page=catalog&category='.$bc['id2'].'">'.$bc['parent2'].'</a></li>';
				if(!empty($bc['parent3'])) 		echo '<li class="breadcrumb-item"><a href="?page=catalog&category='.$bc['id3'].'">'.$bc['parent3'].'</a></li>';
				if(!empty($bc['self'])) 		echo '<li class="breadcrumb-item active">'.$bc['self'].'</li>';
				?>
			  </ol>
			</div>
			<div class="col-lg-3 col-md-5 col-sm-6 pt-2">
				<form method="post" action="index.php" class="form-inline my-2">
						<input class="form-control mr-sm-2" name = "value" type="search" placeholder="Поиск" aria-label="Поиск">
						<input type="hidden" name="page" value="search">	
						<button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Найти</button>
				</form>
			</div>	
	</nav>
<?php
}

function getPathCategory($id)	{
	$bc = array();
			$sql = "SELECT id, name, parent_id FROM category WHERE id=$id";
			$result = getMysqliResult($sql);
			$myrow = $result->fetch_assoc();
			$bc['self'] = $myrow['name'];
			$id = $myrow['id'];
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$myrow['parent_id'];
			$result = getMysqliResult($sql);
			$myrow = $result->fetch_assoc();
			$bc['parent3'] 	= $myrow['name'];
			$id = $myrow['id'];
		}	
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$myrow['parent_id'];
			$result = getMysqliResult($sql);
			$myrow = $result->fetch_assoc();
			$bc['parent2'] 	= $myrow['name'];
			$id = $myrow['id'];
		}	
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$myrow['parent_id'];
			$result = getMysqliResult($sql);
			$myrow = $result->fetch_assoc();
			$bc['parent1'] 	= $myrow['name'];
			$id = $myrow['id'];
		}
	return $bc;
}

?>
<!-- 