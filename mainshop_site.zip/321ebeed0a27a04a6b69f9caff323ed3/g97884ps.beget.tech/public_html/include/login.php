<?php
function isLoginUser($user="",$pass="")	{ // Проверка логина и пароля
	if($user == "") $user = $_REQUEST["email"];
	if($pass == "") $pass = $_REQUEST["password"];
	$validUser = false;
	// Проверка пользователя
	$sql = "SELECT * FROM user WHERE email='".$user."'";
	$result = getMysqliResult($sql);
	if ($result) {
	  while ($myrow = $result->fetch_assoc()) {
               if ($myrow['email'] == $user) {
               // Пользователь существует, проверка пароля
               if (trim($myrow['password']) == trim(md5($pass)))	{
            	 $validUser= true;
            	 $_SESSION['userName'] = $user;
				 $_SESSION['userid'] = $myrow['id'];
               }
               break;
              }
	  }
	}
    if (!$validUser) {
	$_SESSION['error'] = "Некорректное имя пользователя или пароль!";
	return false;
	}
    if ($validUser) {
	$_SESSION['validUser'] = true;
	return true;
	}
    else {
	$_SESSION['validUser'] = false;
	return false;
	}
}

function logoutUser()	{ // Функция выхода пользователя из системы
	unset($_SESSION['userid']);
	unset($_SESSION['userName']);
	unset($_SESSION['validUser']);
}

function loginOk($username)	{
		if(empty($username)&&(isset($_SESSION['userName']))) $username = $_SESSION['userName'];
		if (!empty($username)) { 	
			echo '<li class="nav-item"><a style="color:white;" class="nav-link" href="admin.php?rlaction=logoutUser">Выйти!</a></li>';
		}
}

function loginForm($error = "")	{ // Форма входа
?>
<h1 class="text-center top">Вход в систему</h1>
<div class="row" style="margin-top:10px;">
	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>
	<div class="p-3 col-xs-10 col-sm-6 col-md-4 col-lg-4 reglog">
		<div class="close"><a class="nav-link" href='admin.php'><span class="btnicon icon-close"></span></a></div>
		<form  data-toggle="validator" role="form" enctype="multipart/form-data"  name="loginform" action="admin.php" method="POST"class="m-3">
			  <div class="form-group row">
				<label for="inputEmail" class="control-Label col-lg-5 col-md-5 col-sm-5 col-xs-5">Email *</label>
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
					<input type="email" name = "email" class="form-control" id="inputEmail" placeholder="Email" required = "true">
				</div>
				<div class="help-block with-errors"></div>
			  </div>
			  <div class="form-group row">
				<label class="col-lg-5 col-md-5 col-sm-5 col-xs-5">Пароль *</label>
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
					<input value="" class="form-control" name="password" placeholder="Пароль" type="password"  required = "true" data-minlength="6"/>
				</div>
			  </div>
			  <div class="text-center"><button type="submit" class="btn btn-primary">Войти</button></div>
			  <input name="rlaction" value="IsLoginUser" type="hidden" />
			<hr><span class='text-red font-weight-bold'>*</span> - обязательные для заполнения поля
		</form>
		<a class="nav-link" href = "admin.php?rlaction=passwordForgetForm">Забыли пароль?</a>
	</div>
	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>
</div>
<?php   
}

function action_login()	{
if(((!$_SESSION["validUser"])||($_REQUEST['func'] == "logout"))&&($_REQUEST['rlaction']<>"registerForm")&&($_REQUEST['rlaction'] <> 'isRegisterUser')||($_SESSION['registerUser'])) loginForm("");
		elseif(($_REQUEST['rlaction']<>"registerForm")&&($_REQUEST['rlaction'] <> 'isRegisterUser')) loginOk($_SESSION['userName']);
		elseif(!empty($_SESSION['error'])) registerForm();
}

function login_registr()	{
	if((!empty($_SESSION["validUser"]))&&($_GET['rlaction']<>'loginForm')&&($_GET['rlaction']<>'registerForm')) { 
		echo '<li class="nav-item"><a style="color:white;" class="nav-link" href="admin.php?rlaction=registerForm&rlvalue='.$_SESSION['userid'].'">Изменить пароль</a></li>';
		loginOk($_SESSION['userName']);
		return;
	}
	if(!(is_admin()||is_user())) {
		echo '						<li class="nav-item"><a style="color:white;" class="nav-link" href="admin.php?rlaction=loginForm">Войти</a></li>'.PHP_EOL;
		echo '						<li class="nav-item"><a style="color:white;" class="nav-link" href="admin.php?rlaction=registerForm">Зарегистрироваться</a></li>'.PHP_EOL;
	}
}

function logout()	{  // 
	unset($_SESSION['validUser']); 
	unset($_SESSION['userName']);
	loginForm();
}


include("passwordfunctions.php");
?>