<?php
function index()	{
?>
<h1 class="text-center" >Ваши предложения</h1>
<div style="margin-bottom:70px;" class="mt-2 container-fluid">
<div class="row">
	<div class="col-lg-3 col-md-2 col-sm-1"></div>
	<div class="col-lg-6 col-md-8 col-sm-10 bg-light p-2">
	</div>
	<div class="col-lg-3 col-md-2 col-sm-1"></div>
</div>
<div class="row">
	<div class="col-lg-3 col-md-2 col-sm-1"></div>
	<div class="col-lg-6 col-md-8 col-sm-10 bg-light p-2">
		<form enctype='multipart/form-data' action='?page=request' method='post'>
		  <div class="form-group">
			<label>ФИО</label>
			<input type="text" name = "fio" class="form-control" placeholder="Введите Ваше ФИО">
		  </div>
		  <div class="form-group">
			<label>Город *</label>
			<input type="text" name = "city" required="true" class="form-control" placeholder="Укажите город">
		  </div>
		  <div class="form-group">
			<label class="w-100">Ваше предложение</label>
			<small>Напишите подробно Ваше предложение</small>
			<textarea name="content" class="form-control" rows="3"></textarea>
		  </div>
		  <div class="form-group">
			<label>Почта *</label>
			<input name="email" type="email"  required="true" class="form-control"  required="true" placeholder="Введите email">
		  </div>
		  <div class="form-group">
			<label>Номер телефона</label>
			<input type="phone" name = "phone" class="form-control" placeholder="Введите Ваш контактный телефон">
		  </div>
		  <div class="w-100 text-center"><button type="submit" class="btn btn-primary">Отправить</button></div>
		  <input type='hidden' name='action' value = 'sendMail'>
		</form>
	</div>
	<div class="col-lg-3 col-md-2 col-sm-1"></div>
</div>
</div>
<?php } ?> 

<?php
function sendMail()	{
$email = 'admin@mail.ru';
// Отсылаем письмо
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";

$headers .= "From: ".$_POST['email']."\r\n";
$subject = 'Заявка с сайта из раздела "Ваши предложения"';
$cont = "<b>Здравствуйте!<br>Поступила новая заявка из раздела \"Ваши предложения\".</b><br><br>".
		"ФИО          :".$_POST['fio']."<br>".
		"Город        :".$_POST['city']."<br>".
		"Предложение  :".$_POST['comment']."<br>".
		"E-mail       :".$_POST['email']."<br>".
		"Телефон      :".$_POST['phone']."<br>".
	"<hr>
	С уважением,<br>администратор сайта.";
// Отправляем письмо
	if (mail($email, $subject, $cont, $headers)) echo "<div class='text-center text-success mt-3'>БЛАГОДАРИМ ВАС! ВАША ЗАЯВКА ОТПРАВЛЕНА!</div>";
}
?>