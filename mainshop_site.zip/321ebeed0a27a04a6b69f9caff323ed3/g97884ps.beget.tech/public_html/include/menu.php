<!-- Блок вывода меню -->
<nav style="background-color:#85b7ed" class="navbar navbar-expand-lg navbar-dark">
	<a class="navbar-brand" href="index.php">
		<img src="images/logo2.png" width="200" height="50" class="d-inline-block align-top" alt="">
	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="navbarNav">
		<ul class="navbar-nav">
			<?php getMenuList(); // Вывод пунктов меню из базы 
			if($_SESSION['validUser']) { 
				if(is_admin())	{
				?>
				<li class="nav-item">
					<a style="color:white" class="nav-link font-weight-bold" href="admin.php">Админпанель</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php">Главная</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=about">О магазине</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=catalog">Каталог</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=contacts">Контакты</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=news">Новинки</a>
				</li>
			<?php } 
				else {
				?>
				<li class="nav-item">
					<a style="color:white"  class="nav-link font-weight-bold" href="admin.php">Кабинет</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php">Главная</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=about">О магазине</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=catalog">Каталог</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=contacts">Контакты</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=news">Новинки</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="?page=cart"><img src="images/cart.png" width="50" title="Моя корзина"></a>
				</li>
				<?php } ?>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="admin.php?rlaction=logOut">Выйти</a>
				</li>
				<?php 
			} 
			else  {
			?>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php">Главная</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=about">О магазине</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=catalog">Каталог</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=contacts">Контакты</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="index.php?page=news">Новинки</a>
				</li>
				<li class="nav-item">
					<a style="color:white"  class="nav-link" href="admin.php?rlaction=loginForm">Войти</a>
				</li>
			<?php } ?>
		</ul>
	</div>
</nav>

<?php
function menu($url)	{	// Функция вывода содержимого страницы меню либо из соответствующего файла либо из таблицы
	$sql = "SELECT * FROM menu WHERE url = '".$url."'";
	$result = getMysqliResult($sql);
	if($result) $menu = $result->fetch_assoc();
	if(!empty($menu['content'])) {	// Если есть данные в таблицы, выводим их
		echo "<div class='px-3'>";
		echo "<h1>".$menu['name']."</h1>";
		echo $menu['content'];
		echo "</div>";
	}
	elseif(file_exists('include/'.$url.".php")) include('include/'.$url.".php");	// иначе из соответствующего файла
} 

function getMenuList()	{	// Вывод списка меню из таблицы
	if(!empty($_GET['page'])) $active_page = $_GET['page'];
	$sql = "SELECT * FROM menu WHERE 1";
	$result = getMysqliResult($sql);
	if($result) 
		While($menu = $result->fetch_assoc())	{
			echo '<li class="nav-item '.(($menu['url'] == $active_page)?'active':'').'"><a  style="color:white" class="nav-link" href="?page='.$menu['url'].'">'.$menu['name'].'</a></li>';
		}
	}
?>


