<?php
function isRegisterUser($user="", $pass1="", $pass2="") { // Обработчик формы регистрации
	if($user == "")  $user  = $_REQUEST["email"];
	if($pass1 == "") $pass1 = $_REQUEST["password"];
	if($pass2 == "") $pass2 = $_REQUEST["password1"];
	$errors = array();
	// Проверка паролей
	if (strlen($pass1) < 6) { $errors[] = "Пароль слишком короткий!"; }
	if ($pass1 != $pass2)   { $errors[] = "Пароли не совпадают!";     }

	// Проверка на наличие логина
	$sql = "SELECT * FROM user WHERE email='".$user."'";
	$result = getMysqliResult($sql);
	$myrow  = $result->fetch_assoc();
	if ((!empty($myrow))&&(empty($_POST['id']))) $errors[] = "Такой e-mail уже занят!";

	if(sizeof($errors) >0 )	{
		$_SESSION['error'] = implode("<br>",$errors);
		$_SESSION['registerUser'] = false; 
		return;
	}
	
	$userpass = md5($pass1);
	if(empty($_POST['id'])) {
		$sql = "INSERT INTO user (password, firstname, lastname, fname, email, userstatus_id, phone) VALUES ('".$userpass."','".$_POST['firstname']."','".$_POST['lastname']."','".$_POST['fname']."','".$_POST['email']."',2,'".$_POST['phone']."')"; 
		$result = getMysqliResult($sql);
		if ($result) {
			$_SESSION['registerUser'] = true;
			$_SESSION['success'] = "Пользователь успешно зарегистрирован";
		}
		else $_SESSION['error'] = "Ошибка регистрации пользователя";
	}
	else {
		$sql = "UPDATE user SET password ='".md5($pass1)."' WHERE id = ".$_POST['id'];
		$result = getMysqliResult($sql);
		if ($result) 
			$_SESSION['success'] = "Пароль успешно изменен!";
	}
}

function registerForm($id = 0)	{  // Форма регистрации
	  $button_label = "Зарегистрироваться";
	  $header = 'Регистрация нового пользователя';
	  if(!empty($id))	{
		  $sql = "SELECT * FROM user WHERE id = ".$id;
		  $result = getMysqliResult($sql);
		  if($result) $myrow = $result->fetch_assoc();
		  $button_label = "Обновить";
		  $dis = " disabled ";	
		  $header = 'Изменение пароля';
	  }
 ?>	
 <h1><?php echo $header; ?></h1>
 <div class="row" style="margin-top:10px;">
	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>
	<div class="p-3 col-xs-10 col-sm-6 col-md-4 col-lg-4 reglog">
		<div class="close"><a href='admin.php'><span class="btnicon icon-close"></span></a></div>
		<form  enctype="multipart/form-data"  name="loginform" action="admin.php" method="POST" class="m-3">
			<div class="form-group row">
				<label class="col-lg-5 col-md-5 col-sm-5 col-xs-5">E-mail *</label>
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
					<input value = "<?php echo $myrow['email'];?>" class="form-control" name="email" placeholder="E-mail" type="email" <?php echo $dis;?> />
				</div>
			</div>
			<div class="form-group row">
				<label class="col-lg-5 col-md-5 col-sm-5 col-xs-5">Пароль (минимум 6 символов) *</label>
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
					<input minlength="6" value="" class="form-control" name="password" placeholder="Пароль" type="password"   required = "true" data-minlength="6"/>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-lg-5 col-md-5 col-sm-5 col-xs-5">Повтор пароля *</label>
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
					<input minlength="6" value="" class="form-control" name="password1" placeholder="Повтор пароля" type="password"    required = "true" data-minlength="6"/>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-lg-5 col-md-5 col-sm-5 col-xs-5">Фамилия *</label>
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
					<input class="form-control" value = "<?php echo $myrow['lastname'];?>" name="lastname" placeholder="Фамилия" type="text"   required = "true"  <?php echo $dis;?> />
				</div>
			</div>
			<div class="form-group row">
				<label class="col-lg-5 col-md-5 col-sm-5 col-xs-5">Имя *</label>
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
					<input class="form-control" value = "<?php echo $myrow['firstname'];?>" name="firstname" placeholder="Имя" type="text"   required = "true"  <?php echo $dis;?> />
				</div>
			</div>
			<div class="form-group row">
				<label class="col-lg-5 col-md-5 col-sm-5 col-xs-5">Отчество</label>
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
					<input class="form-control" value = "<?php echo $myrow['fname'];?>" name="fname" placeholder="Отчество" type="text"  <?php echo $dis;?> />
				</div>
			</div>
			<div class="form-group row">
				<label class="col-lg-5 col-md-5 col-sm-5 col-xs-5">Телефон</label>
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
					<input class="form-control" value = "<?php echo $myrow['phone'];?>" name="phone" placeholder="Телефон" type="phone"  <?php echo $dis; ?> />
				</div>
			</div>
			<div class="form-group row">
				<label class="col-lg-5 col-md-5 col-sm-5 col-xs-5" for="exampleFormControlSelect1" >Статус *</label>
				<div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
					<select disabled="true" class="form-control" id="exampleFormControlSelect1" name="userstatus_id"  <?php echo $dis;?>  >
<?php
			$sql = "SELECT * FROM userstatus WHERE 1 ORDER BY id DESC";
			$result = getMysqliResult($sql);
			if ($result) 
				while ($mrow = $result->fetch_assoc())
				   echo "						<option style='text-align:center' ".(($mrow['id'] == $myrow['userstatus_id'])?"SELECTED":"")." value=".$mrow['id'].">".$mrow['name']."</option>";
?>
					</select>
				</div>
			</div>
			<div class="text-center">
				<button type="submit" class="mx-auto btn btn-primary"><?php echo $button_label;?></button>
			</div>
   			<input name="id" value="<?php if(isset($id)) echo $id; ?>" type="hidden" />
   			<input name="rlaction" value="IsRegisterUser" type="hidden" />
			<hr><span class='text-red font-weight-bold'>*</span> - обязательные для заполнения поля
		</form>
	</div>
	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>
</div>
<?php
}
?>