<div class="p-2">
<h1>Контакты</h1>
<p>г.Симферополь проспект Ленина 33/3 офис 601</p>
<div id="wrapper-9cd199b9cc5410cd3b1ad21cab2e54d3">
		<div id="map-9cd199b9cc5410cd3b1ad21cab2e54d3"></div><script>(function () {
        var setting = {"height":534,"width":1400,"zoom":17,"queryString":"проспект Ленина, 33/3, г. Кемерово, Россия","place_id":"ChIJcy3K4fkL2EIR_8FoHDw2DS4","satellite":false,"centerCoord":[55.344153122971825,86.07617140000002],"cid":"0x2e0d363c1c68c1ff","id":"map-9cd199b9cc5410cd3b1ad21cab2e54d3","embed_id":"41633"};
        var d = document;
        var s = d.createElement('script');
        s.src = 'https://1map.com/js/script-for-user.js?embed_id=41633';
        s.async = true;
        s.onload = function (e) {
          window.OneMap.initMap(setting)
        };
        var to = d.getElementsByTagName('script')[0];
        to.parentNode.insertBefore(s, to);
      })();</script>
</div>