<?php
$config = array(
			'siteTitle'			=>'Fan-D | Самые популярные книги', 
			'siteDescription'	=>'Fan-D | Самые популярные книги', 
			'siteKeywords'  	=>"Fan-D, продажа книг, низкие цены",
 			'base'				=>'g97884ps_main'
				);