<?php
	// Функция вывода всех записей в панель
    function index(){
?>
		<h1>Категории</h1>
		<div class="text-center"><a href='?table=category&action=insertForm'>Добавить новую запись</a></div>
<?php
		$sql = "SELECT `id`,`name`,`image`,`parent_id` FROM `category` WHERE 1 ORDER BY id";
		$result = getMysqliResult($sql);
		if($result->num_rows > 0)	{
?>
		<table class="shadow-lg">
			<tr><th></th>
				<th>Номер</th>
				<th>Наименование</th>
				<th>Изображение</th>
				<th>Родительская категория</th>
			</tr>
<?php	
			$i = 0;
			while ($item = $result->fetch_assoc()) {
				$i++;
				if(!empty($item["parent_id"])) $item["parent_id"] = getParentName($item["parent_id"]);
?>
				<tr>
					<td>
						<!-- Кнопки удаления и редактирования -->
						<a  onclick='return confirmSpelll();' href='?table=category&action=delete&id=<?php echo $item['id']; ?>'><img src='images/del.png'></a>
						<a href='?table=category&action=updateForm&id=<?php echo $item['id']; ?>'><img src='images/edit.png'></a>
						<!-------------------------------------->
					</td>
					<td class='text-center'><?php echo $item['id']; ?></td>
					<td class='text-center'><?php echo $item['name']; ?></td>
					<td class='text-center'><img style='width:80px;' src ='<?php if(file_exists($item['image'])) echo $item['image']; else echo 'images/noimage.png'; ?>' title='<?php echo $item['name']; ?>'></td>
					<td class='text-center'><?php getParentLinkSelect($item['id'], $item['parent_id']); ?></td>
				</tr>
<?php	
			}
?>		</table>
<?php
		}
	}

   	// Функция формы ввода для обновления записи в таблице
    function updateForm($id){
		$sql = "SELECT * FROM category WHERE id=".$id;
		$result = getMysqliResult($sql);
		if($result)	$item = $result->fetch_assoc();
?>
		<h3 class='text-center top text-primary mt-2' >Редактирование записи № <?php echo $id; ?> в таблице Категории</h3>
		<div class='row margin-bottom-50 mx-3'>
			<div class="col-xs-1 col-sm-2 col-md-2 col-lg-3"></div>
			<div class="p-4 col-xs-10 col-sm-8 col-md-8 col-lg-6 shadow-lg border rounded">
				<div style="position:relative;width:100%; text-align:right; float:right;right:-13px;">
					<a href="admin.php?table=category"><span style="color:grey; font-size:20px" class="btnicon icon-close"></span></a>
				</div>
				<form enctype='multipart/form-data' action='?table=category' method='post'>
					<div class='form-group row w-100'>
						<label class=' font-weight-bold col-lg-5 col-md-5 col-sm-12 col-xs-12' style='word-wrap: break-word;'>Наименование *</label>
						<div class='col-lg-7 col-md-7 col-sm-12 col-xs-12' >
							<input  required='true' class='form-control' name='name'          type='text'          value='<?php echo $item['name']; ?>')/>
						</div>
					</div>
					<div class='form-group row w-100'>
						<label class=' font-weight-bold col-lg-5 col-md-5 col-sm-12 col-xs-12' style='word-wrap: break-word;'>Изображение *</label>
						<div class='col-lg-7 col-md-7 col-sm-12 col-xs-12' >
<?php 	if((!empty($item['image']))&&(file_exists($item[image]))) 
				echo '							<img width = "25%" src="'.$item['image'].'">'.PHP_EOL;
?>							<input  class='mt-1' id = 'image' name = 'image' type='file' accept='image/*'/>
							<input name = 'imagename' type = 'hidden' value='<?php echo $item['image']; ?>' />
							<small>Допустимые форматы – jpeg, jpg, bmp, png</small>						</div>
					</div>
					<div class='form-group row w-100'>
						<label class=' font-weight-bold col-lg-5 col-md-5 col-sm-12 col-xs-12' style='word-wrap: break-word;'>Родительская категория *</label>
						<div class='col-lg-7 col-md-7 col-sm-12 col-xs-12' >
<?php echo getParentSelect($item['id'], $item['parent_id']); ?>
						</div>
					</div>
					<input type='hidden' 	name='action' 	value = 'update'>
					<input type='hidden' 	name='table' 	value = 'category'>
					<input type='hidden' 	name='id' 		value = '<?php echo $id; ?>'>
					<div class="text-center">
						<input style="width:200px;" class="submit btn btn-primary form-control mt-2" id="Submit" value="Сохранить изменения" type="submit" name="Submit" >
					</div>
					<span class='text-red font-weight-bold'>*</span> - обязательные для заполнения поля
				</form>
			</div>
			<div class="col-xs-1 col-sm-1 col-md-2 col-lg-3"></div>
		</div>
<?php	}

   	// Функция формы ввода для добаления записи в таблицу
    function insertForm(){
?>
		<h3 class='text-center top text-primary mt-2' >Добавление записи в таблицу Категории</h3>
		<div class='row margin-bottom-50 mx-3'>
			<div class="col-xs-1 col-sm-2 col-md-2 col-lg-3"></div>
			<div class="p-4 col-xs-10 col-sm-8 col-md-8 col-lg-6 shadow-lg border rounded">
				<div style="position:relative;width:100%; text-align:right; float:right;right:-13px;">
					<a href="admin.php?table=category"><span style="color:grey; font-size:20px" class="btnicon icon-close"></span></a>
				</div>
				<form enctype='multipart/form-data' action='?table=category' method='post'>
					<div class='form-group row w-100'>
						<label class=' font-weight-bold col-lg-5 col-md-5 col-sm-12 col-xs-12' style='word-wrap: break-word;'>Наименование *</label>
						<div class='col-lg-7 col-md-7 col-sm-12 col-xs-12' >
							<input  required='true' class='form-control' name='name'          type='text'          />
						</div>
					</div>
					<div class='form-group row w-100'>
						<label class=' font-weight-bold col-lg-5 col-md-5 col-sm-12 col-xs-12' style='word-wrap: break-word;'>Изображение *</label>
						<div class='col-lg-7 col-md-7 col-sm-12 col-xs-12' >
							<img width = "25%" src="images/noimage.png">
							<input  class='mt-1' id = 'image' name = 'image' type='file' accept='image/*'/>
							<small>Допустимые форматы – jpeg, jpg, bmp, png</small>						</div>
					</div>
					<div class='form-group row w-100'>
						<label class=' font-weight-bold col-lg-5 col-md-5 col-sm-12 col-xs-12' style='word-wrap: break-word;'>Родительская категория *</label>
						<div class='col-lg-7 col-md-7 col-sm-12 col-xs-12' >
<?php echo getParentInsertSelect($item['id']); ?>
						</div>
					</div>
					<input type='hidden' 	name='action' 	value = 'insert'>
					<input type='hidden' 	name='table' 	value = 'category'>
					<input type='hidden' 	name='id' 		value = '<?php echo $id; ?>'>
					<div class="text-center">
						<input style="width:200px;" class="submit btn btn-primary form-control mt-2" id="Submit" value="Добавить" type="submit" name="Submit" >
					</div>
					<span class='text-red font-weight-bold'>*</span> - обязательные для заполнения поля
				</form>
			</div>
			<div class="col-xs-1 col-sm-1 col-md-2 col-lg-3"></div>
		</div>
<?php	}

 	// Функция обновляет запись в таблице
 	function update()	{
		$post = $_POST;
		$files = $_FILES;
		if (!empty($files))	{
			$uploaddir = 'uploads/';
			foreach($files as $ki=>$f)	{
 				$var = $ki."name";
				if((!file_exists($files[$ki]['tmp_name']))&&(!empty($files[$ki]['name']))) {
					echo "<p style='margin-top: 20px;' class='text-center'><span style='color:red;'>Ошибка загрузки файла (размер файла превышает ".max_file_upload_in_bytes()." Kb)!</span></p>";
					updateForm($post['id']);
					return;
				}
				$arr = explode(".", basename($files[$ki]['name']));
				$end = end($arr);
				$uploadfile  = $uploaddir . str_replace("-".$end,".".$end,str2url(basename($files[$ki]['name'])));
				if (basename($files[$ki]['name'])) 	{
					move_uploaded_file($files[$ki]['tmp_name'] , $uploadfile);
					$post[$ki] = $uploadfile;
				} 	else $post[$ki] = $post[$var];

					unset($post[$var]);
			}
		}

		$table = $post['table'];
		$id = $post['id'];
		unset($post['Submit'],$post['action'],$post['table'],$post['id']);
		$values = array();
		
		foreach($post as $key=>$val) $values[] = $key." = '".$val."'";	
		$sql = "UPDATE category SET ".implode(",",$values)." WHERE id=".$id;
		$result = getMysqliResult($sql);
		index();
	}

	// Функция добавляет запись в таблицу
 	function insert()	{
		$post = $_POST;
		$files = $_FILES;
		if (!empty($files))	{
			$uploaddir = 'uploads/';
			foreach($files as $ki=>$f)	{
				if((!file_exists($files[$ki]['tmp_name']))&&(!empty($files[$ki]['name']))) {
					echo "<p style='margin-top: 20px;' class='text-center'><span style='color:red;'>Ошибка загрузки файла (размер файла превышает ".max_file_upload_in_bytes()." Kb)!</span></p>";
					insertForm();
					return;
				}
				$arr = explode(".", basename($files[$ki]['name']));
				$end = end($arr);
				$uploadfile  = $uploaddir . str_replace("-".$end,".".$end,str2url(basename($files[$ki]['name'])));
				if (basename($files[$ki]['name'])) 	{
					move_uploaded_file($files[$ki]['tmp_name'] , $uploadfile);
					$post[$ki] = $uploadfile;
				} 	
			}
		}

		$table = $post['table'];
		$id = $post['id'];
		unset($post['Submit'],$post['action'],$post['table'],$post['id']);
		
		$values = "'".implode("','",array_values($post))."'";
		$keys = implode(",",array_keys($post));
		$sql = "INSERT INTO category (".$keys.") VALUES (".$values.")";
		$result = getMysqliResult($sql);
		index();
	}
	
	// Функция удаляет запись из таблицы
	function delete($id)	{
		$sql = "DELETE FROM category WHERE id=".$id;
		$result = getMysqliResult($sql);
		index();
	}
	
		// Функция выдачи select-списка для изменения роли Категории
	function getParentLinkSelect($id, $status)	{ 
?>
		<select class="form-control" onchange="location = this.value;">
			<option>-------------</option>
<?php
				$sql = "SELECT * FROM category WHERE id<>$id ORDER BY name";
				$result = getMysqliResult($sql);
				if($result->num_rows > 0) while($option = $result->fetch_assoc())	{ 
					$selected = ($status == $option['name'])?"selected":"";
?>
								<option <?php echo $selected; ?> value="?table=category&action=changeParent&id=<?php echo $id; ?>&parent_id=<?php echo $option['id']; ?>"><?php echo $option['name']; ?></option>
<?php			} ?>
							</select>
<?php
	}
	
	// Функция выдачи select-списка для формы обновления Категории
	function getParentSelect($id, $status)	{ 
?>
							<select name = "parent_id" class="form-control">
								<option>-------------</option>
<?php
				$sql = "SELECT * FROM category WHERE id<>$id ORDER BY name";
				$result = getMysqliResult($sql);
				if($result->num_rows > 0) while($option = $result->fetch_assoc())	{ 
					$selected = ($status == $option['id'])?"selected":"";
?>
								<option <?php echo $selected; ?> value="<?php echo $option['id']; ?>"><?php echo $option['name']; ?></option>
<?php			} ?>
							</select>
<?php
	}
	
	// Функция выдачи select-списка для формы добавления Категории
	function getParentInsertSelect()	{ 
?>
							<select name = "parent_id" class="form-control">
								<option>-------------</option>
<?php
				$sql = "SELECT * FROM category WHERE 1 ORDER BY name";
				$result = getMysqliResult($sql);
				if($result->num_rows > 0) while($option = $result->fetch_assoc())	{ 
?>
								<option value="<?php echo $option['id']; ?>"><?php echo $option['name']; ?></option>
<?php			} ?>
							</select>
<?php
	}
	
	// Функция изменения родителя
	function changeParent($id)	{ 
		$sql = "UPDATE category SET parent_id = ".$_GET['parent_id']." WHERE id=".$id;
		$result = getMysqliResult($sql);
		index();
	}

	// Функция возвращает имя родительского элемента
	function getParentName($id)	{
		$sql = "SELECT name FROM category WHERE id=$id";
		$result = getMysqliResult($sql);
		if($result->num_rows>0) { $item = $result->fetch_assoc(); return $item["name"]; }
		else return "";
	}
