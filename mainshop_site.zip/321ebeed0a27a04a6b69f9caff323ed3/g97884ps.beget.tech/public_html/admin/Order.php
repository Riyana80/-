<?php
	// Вывод всех записей в панель
    function index($user_id = NULL){
		?>
		<h1>Заказы</h1>
		<?php
		if(!empty($user_id))
			$sql = "SELECT id,date,(SELECT name FROM orderstatus WHERE id=O.orderstatus_id) as orderstatus,(SELECT CONCAT(lastname,' ',firstname,' ',fname) FROM `user` WHERE id=O.user_id) AS fio,(SELECT phone FROM `user` WHERE id=O.user_id) AS phone,(SELECT email FROM `user` WHERE id=O.user_id) AS email,comment,orderstatus_id FROM `order` AS O WHERE user_id=".$user_id." ORDER BY id";
		else
			$sql = "SELECT id,date,(SELECT name FROM orderstatus WHERE id=O.orderstatus_id) as orderstatus,(SELECT CONCAT(lastname,' ',firstname,' ',fname) FROM `user` WHERE id=O.user_id) AS fio,(SELECT phone FROM `user` WHERE id=O.user_id) AS phone,(SELECT email FROM `user` WHERE id=O.user_id) AS email,comment,orderstatus_id FROM `order` AS O WHERE 1 ORDER BY id";
		$result = getMysqliResult($sql);
		if($result)	{
		?>
		<div class="px-3">
		<table>
			<tr>
				<th>Номер</th>
				<th>Дата и время</th>
				<th>ФИО</th>
				<th>Телефон</th>
				<th>E-mail</th>
				<th>Комментарий</th>
				<th>Сумма</th>
				<th>Статус</th>
				<th>Подробности</th>
			</tr>
		<?php	
			$i = 0;
			$total = 0;
			while ($order = $result->fetch_assoc()) {
				$i++;
				$sql1 = "SELECT OP.*, (SELECT name FROM product WHERE id=OP.product_id) AS name FROM `order_product` AS OP WHERE order_id = ".$order['id']." ORDER BY id";
				$result1 = getMysqliResult($sql1);
				$products = "";
				while($product = $result1->fetch_assoc()) $products .= $product['image']."  ".$product['name']." (".$product['kol']." шт.)".PHP_EOL;
				?> 
					<tr>
						<td><?php echo $order['id']; ?>	</td>
						<td><?php echo date("d/m/Y", strtotime(left($order['date'],10)))."<br>".left(right($order['date'],8),5); ?>	</td>
						<td><?php echo $order['fio']; ?>	</td>
						<td><?php echo $order['phone']; ?>	</td>
						<td><?php echo $order['email']; ?>	</td>
						<td><?php echo $order['comment']; ?>	</td>
						<td><?php echo getOrderSumma($order['id']); ?>	</td>
						<td class='text-center'>
						<?php 
							if(is_admin()||is_manager())	{
								if($order['orderstatus_id']==1) getLinkSelect($order['id'], $order['orderstatus']); else echo $order['orderstatus']; 
							}
							else echo $order['orderstatus'];
						?>
						</td>
						<td><?php echo "<a href = 'admin.php?table=order&action=view&id=".$order['id']."' title='".$products."'>Товары</a>"; ?></td>
					</tr>
				<?php	
			}
		}
		echo "</table>".PHP_EOL;
		echo "</div>".PHP_EOL;
    }

    // Функция вывода одной записи в вид
    function view($id)	{
		?>
		<h1 class="ml-4">Подробности заказа № <?php echo $id; ?></h1>
		<div style="margin:10px 10px 60px 10px;" class="container-fluid text-center">
			<div style="padding:10px" class="row bg-info mx-auto w-75">
				<div class="col-lg-2 col-md-2 col-sm-12 text-center border border-dark p-2 d-none d-md-block">Фото</div>
				<div class="col-lg-4 col-md-4 col-sm-12 text-center border border-dark p-2 d-none d-md-block">Название</div>
				<div class="col-lg-2 col-md-2 col-sm-12 text-center border border-dark p-2 d-none d-md-block">Кол-во</div>
				<div class="col-lg-2 col-md-2 col-sm-12 text-center border border-dark p-2 d-none d-md-block">Цена (руб)</div>
				<div class="col-lg-2 col-md-2 col-sm-12 text-center border border-dark p-2 d-none d-md-block">Итого (руб)</div>
			</div>
		<?php
				$sql1 = "SELECT OP.*, (SELECT name FROM product WHERE id=OP.product_id) AS name, (SELECT price FROM product WHERE id=OP.product_id) AS price , (SELECT image FROM product WHERE id=OP.product_id) AS image FROM `order_product` AS OP WHERE order_id = ".$id." ORDER BY id";
				$result1 = getMysqliResult($sql1);
				while($product = $result1->fetch_assoc()) { 
		?>
			<div style="padding:10px"  class="row bg-white mx-auto w-75">
				<div class="col-6  col-lg-2 col-md-2 col-sm-6  text-center  border border-dark p-2">
					<img width="100" src="<?php echo $product['image']; ?>" alt="">
				</div>
				<div class="col-6  col-lg-4 col-md-4 col-sm-6  text-center  border border-dark p-2 pt-4"><?php echo $product['name']; ?></div>
				<div class="col-6  col-lg-2 col-md-2 col-sm-6  text-center  border border-dark p-2 pt-4"><?php echo $product['kol']; ?></div>
				<div class="col-6  col-lg-2 col-md-2 col-sm-6  text-center  border border-dark p-2 pt-4"><?php echo number_format($product['price'], 2, ',', ' '); ?></div>
				<div class="col-6  col-lg-2 col-md-2 col-sm-6  text-center  border border-dark p-2 pt-4"><?php echo number_format($product['price']*$product['kol'], 2, ',', ' '); ?></div>
			</div>
		<?php }
		echo "<h4 class='text-primary'>Итого сумма заказа ".getOrderSumma($id)." руб. </h4>";
		if(is_user()) echo "<a class='text-center' href='?table=order&id=".userID()."'>Вернуться к списку заказов</a>";
		if(is_admin()) echo "<a class='text-center' href='?table=order'>Вернуться к списку заказов</a>";
	}

    // Сумма заказа
    function getOrderSumma($id)	{
		$sql1 = "SELECT OP.*, (SELECT name FROM product WHERE id=OP.product_id) AS name, (SELECT price FROM product WHERE id=OP.product_id) AS price , (SELECT image FROM product WHERE id=OP.product_id) AS image FROM `order_product` AS OP WHERE order_id = ".$id." ORDER BY id";
		$result1 = getMysqliResult($sql1);
		$total = 0;
		while($product = $result1->fetch_assoc()) { 
			$total += $product['price']*$product['kol'];
		}
		return number_format($total, 2, ',', '&nbsp;');
	}
	
	function delete()	{
		$id = 		$_GET['id'];
		$sql = "DELETE FROM order WHERE id=".$id;
		$result = getMysqliResult($sql);
		index();
	}
	
     // Добавления записи (форма)
    function insertform(){
		updateform();
	}

function endorder($id)	{
	$sql = "UPDATE `order` SET orderstatus_id = 2 WHERE id=".$id;
	$result = getMysqliResult($sql);
	index();
}

function deleteorder($id)	{
	$sql = "UPDATE `order` SET orderstatus_id = 3 WHERE id=".$id;
	$result = getMysqliResult($sql);
	index();
}

		// Функция выдачи select-списка для изменения роли Заказы
	function getLinkSelect($id, $status)	{
?>
		<select class="form-control" onchange="location = this.value;">
<?php
				$sql = "SELECT * FROM orderstatus WHERE 1 ORDER BY id";
				$result = getMysqliResult($sql);
				if($result->num_rows > 0) while($option = $result->fetch_assoc())	{ 
					$selected = ($status == $option['name'])?"selected":"";
?>
								<option <?php echo $selected; ?> value="?table=order&action=changeOrderstatus&id=<?php echo $id; ?>&orderstatus_id=<?php echo $option['id']; ?>"><?php echo $option['name']; ?></option>
<?php			} ?>
							</select>
<?php
	}
	
	// Функция выдачи select-списка для формы обновления
	function getSelect($status)	{
?>
							<select name="orderstatus_id" required="true" class="form-control">
								<option>-------------</option>
<?php
				$sql = "SELECT * FROM orderstatus WHERE 1 ORDER BY name";
				$result = getMysqliResult($sql);
				if($result->num_rows > 0) while($option = $result->fetch_assoc())	{ 
					$selected = ($status == $option['id'])?"selected":"";
?>
								<option <?php echo $selected; ?> value="<?php echo $option['id']; ?>"><?php echo $option['name']; ?></option>
<?php			} ?>
							</select>
<?php
	}
	
	// Функция выдачи select-списка для формы добавления
	function getInsertSelect()	{
?>
							<select  name="orderstatus_id" required="true" class="form-control">
								<option>-------------</option>
<?php
				$sql = "SELECT * FROM orderstatus WHERE 1 ORDER BY name";
				$result = getMysqliResult($sql);
				if($result->num_rows > 0) while($option = $result->fetch_assoc())	{ 
?>
								<option value="<?php echo $option['id']; ?>"><?php echo $option['name']; ?></option>
<?php			} ?>
							</select>
<?php
	}
	
	// Функция изменения роли Заказы 
	function changeOrderstatus($id)	{ 
		$sql = "UPDATE `order` SET `orderstatus_id` = ".$_GET['orderstatus_id']." WHERE id=".$id;
		$result = getMysqliResult($sql);
		index();
	}
