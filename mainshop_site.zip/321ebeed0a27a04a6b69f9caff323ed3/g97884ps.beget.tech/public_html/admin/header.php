				<?php 
				include_once("include/open_db.php");				// Файл подключения к базе данных
				include_once("admin/adminfunctions.php");			// Файл подключения функции
				include_once("include/login.php");					// Файл авторизации
				include_once("include/register.php");				// Файл регистрации
				include_once("include/user.php");					// Файл функций, относящихся к пользователям	
				$rlaction  	= $_REQUEST['rlaction'];				// название функции по авторизации и регистрации
				$rlvalue 	= $_REQUEST['rlvalue'];					// аргумент функции по авторизации и регистрации
				if((!empty($rlaction))&&(function_exists($rlaction))) $rlaction($rlvalue); 
				if(in_array($rlaction, array("IsLoginUser","logOut","logoutUser")))	
						echo ' <script type="text/javascript">
									window.location.href = "index.php"
							</script>';
				if(!empty($_SESSION['error'])) {					// если есть ошибка, выводим ее
					echo "<div style='margin-top:100px;' class='w-100 top bottom'>";
					echo '<div class="text-center text-danger">'.$_SESSION['error'].'</div>';
					unset($_SESSION['error']);
					echo "</div>";
				}
				if(!empty($_SESSION['success'])) {					// если есть сообщение об успешной авторизации, выводим
					echo "<div style='margin-top:100px;'  class='w-100 top bottom'>";
					echo '<div class="text-center text-success">'.$_SESSION['success'].'</div>';
					unset($_SESSION['success']);
					echo "</div>";
				}
				?>
    <header>
	
        <!-- ===========================
         Меню начало
         =========================== -->
		<nav style="background-color:#85b7ed" class="fixed-top navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                           <span class="text-white"><img src="images/menu.png">
                    </button>
                </div>

                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="nav-item"><a style="color:white;"class="nav-link" href="index.php">Главная</a></li>
<?php
						if (is_admin()) {  	// если текущий пользователь - администратор
	                        echo '<li class="nav-item"><a style="color:white;"class="nav-link" href="admin.php?table=menu">Меню</a></li>';
	                        echo '<li class="nav-item"><a style="color:white;"class="nav-link" href="admin.php?table=category">Категории</a></li>';
	                        echo '<li class="nav-item"><a style="color:white;"class="nav-link" href="admin.php?table=product">Товары</a></li>';
	                        echo '<li class="nav-item"><a style="color:white;"class="nav-link" href="admin.php?table=news">Новости</a></li>';
	                        echo '<li class="nav-item"><a style="color:white;"class="nav-link" href="admin.php?table=request">Отзывы</a></li>';
	                        echo '<li class="nav-item"><a style="color:white;"class="nav-link" href="admin.php?table=slide">Слайды</a></li>';
	                        echo '<li class="nav-item"><a style="color:white;"class="nav-link" href="admin.php?table=order">Заказы</a></li>';
	                        echo '<li class="nav-item"><a style="color:white;"class="nav-link" href="admin.php?table=user">Пользователи</a></li>';
						}
						if (is_manager()) {  	// если текущий пользователь - менеджер
	                        echo '<li class="nav-item"><a style="color:white;"class="nav-link" href="admin.php?table=request">Отзывы</a></li>';
	                        echo '<li class="nav-item"><a style="color:white;"class="nav-link" href="admin.php?table=order">Заказы</a></li>';
						}
						if (is_user()) {  // если текущий пользователь - пользователь
	                        echo '<li class="nav-item"><a style="color:white;"class="nav-link" href="admin.php?table=order&id='.userID().'">Мои заказы</a></li>';
						}
?>
<?php login_registr(); // Функция авторизации и регистрации } ?>
                   </ul>
                </div>
            </div>
        </nav>
        <!-- конец меню -->
    </header>
