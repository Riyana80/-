<?php
	// Вывод всех записей в панель
    function index(){
		?>
			<script>
				function confirmSpelll() {
				if (confirm("Вы действительно хотите удалить этот элемент?")) return true;
				else return false;
				}
			</script>
		<h1>Новости</h1>
		<center><a href='?table=news&action=insertform'>Добавить новый</a></center>
		<?php
		$sql = "SELECT id,name,image,content FROM `news` WHERE 1 ORDER BY id";
		$result = getMysqliResult($sql);
		if($result)	{
		?>
		<table>
			<tr>
				<th></th>
				<th>Номер</th>
				<th>Наименование</th>
			</tr>
		<?php	
			$i = 0;
			while ($news = $result->fetch_assoc()) {
				$i++;
				?> 
					<tr>
						<td style='width:70px;'>
							<a  onclick='return confirmSpelll();' href='?table=news&action=delete&id=<?php echo $news['id']; ?>'><img src='images/del.png'></a>&nbsp;&nbsp;
							<a href='?table=news&action=updateform&id=<?php echo $news['id']; ?>'><img src='images/edit.png'></a>
						</td>
						<td><?php echo $i; ?>	</td>
						<td><?php echo $news['name']; ?>	</td>
					</tr>
				<?php	
			}
		}
		echo "</table>";
    }

    // Обновления записи (форма)
     function updateform($id = NULL){
		if(!empty($id))	{
			$sql = "SELECT * FROM news WHERE id=".$id;
			$result = getMysqliResult($sql);
		if($result)
			$news = $result->fetch_assoc();
		}
		else {
			$fields = "id,name,image,content";
			foreach(explode(",",$fields) as $f) $news[$f] = '';
		}
		if(!empty($id)) echo "<h1 class='text-center top' >Редактирование записи № ".$id." в таблице Новости</h1></center>".PHP_EOL;
		else echo "<center><h1  class='text-center top' >Добавление записи в таблицу Новости</h1></center>".PHP_EOL;
		echo "<div class='row'>".PHP_EOL;
		echo '	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>'.PHP_EOL;
		echo '	<div class="p-3 col-xs-10 col-sm-6 col-md-4 col-lg-4" style="margin:10px auto 20px auto; padding:5px 10px; border:1px solid #ddd; border-radius:10px;">'.PHP_EOL;
		echo '		<div style="position:relative;width:100%; text-align:right; float:right;right:-13px;">'.PHP_EOL;
		echo '			<a href="admin.php"><span style="color:grey; font-size:20px" class="btnicon icon-close"></span></a>'.PHP_EOL;
		echo '		</div>'.PHP_EOL;
		echo "		<form enctype='multipart/form-data' action='?table=news' method='post'>".PHP_EOL;
		echo "			<input type='hidden' name='id' value = '".$id."'>".PHP_EOL;
		?>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Наименование</label>
			<div>
				<input class='form-control' id='name' name='name' type='text' value='<?php echo $news['name']; ?>'/>
			</div>
		</div>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Изображение</label>
			<div>
				<img width = "25%" src="<?php echo $news['image']; ?>">
				<input id = "image" name = "image" type="file" />
				<input cols = "70" name = "imagename" type = "hidden" value="<?php echo $news['image']; ?>" />
			</div>
		</div>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Содержимое *</label>
			<div>
				<textarea class='form-control' id='content'  required = "true" cols="80" rows="3" name='content'><?php echo $news['content']; ?></textarea>
			</div>
		</div>

<?php
		if(!empty($id)) echo "			<input type='hidden' name='action' value = 'update'>".PHP_EOL;
		else echo "			<input type='hidden' name='action' value = 'insert'>".PHP_EOL;
		echo "			<input type='hidden' name='table' value = 'news'>".PHP_EOL;
		if(!empty($id)) echo '			<div class="text-center"><input class="submit" id="Submit" value="Сохранить изменения" type="submit" name="Submit" ></div>'.PHP_EOL;
		else echo '			<div class="text-center"><input class="submit" id="Submit" value="Добавить" type="submit" name="Submit" ></div>'.PHP_EOL;
		echo "			<span class='text-red font-weight-bold'>*</span> - обязательные для заполнения поля";
		echo "		</form>".PHP_EOL;
		echo "	</div>".PHP_EOL;
		echo "</div>".PHP_EOL;
	}

// Обновление записи
 	function update()	{
		$post = $_POST;
		$files = $_FILES;
		if (!empty($files))	{
			$uploaddir = 'uploads/';
			foreach($files as $ki=>$f)	{
				$var = $ki."name";
				$arr = explode(".",basename($files[$ki]['name']));
				$end = end($arr);
				$uploadfile  = $uploaddir . str_replace("-".$end,".".$end,str2url(basename($files[$ki]['name'])));
				if (basename($files[$ki]['name'])) 	{
					move_uploaded_file($files[$ki]['tmp_name'] , $uploadfile);
					$post[$ki] = $uploadfile;
				} 	else $post[$ki] = $post[$var];

					unset($post[$var]);
			}
		}
			$table = $post['table'];
			$id = $post['id'];
			unset($post['Submit'],$post['action'],$post['table'],$post['id']);
			$values = array();
			foreach($post as $key=>$val) $values[] = $key." = '".$val."'";
			$sql = "UPDATE news SET ".implode(",",$values)." WHERE id=".$id;
			$result = getMysqliResult($sql);
			index();
	}

// Добавление записи
 	function insert()	{
		$post = $_POST;
		$files = $_FILES;
		if (!empty($files))	{
			$uploaddir = 'uploads/';
			foreach($files as $ki=>$f)	{
				if(!file_exists($files[$ki]['tmp_name'])) {
					echo "<p class='text-center'><span style='color:red;'>Ошибка загрузки файла (размер файла превышает 2Mb)!</span></p>";
					index();
					return;
				}
				$var = $ki."name";
				$arr = explode(".",basename($files[$ki]['name']));
				$end = end($arr);
				$uploadfile  = $uploaddir . str_replace("-".$end,".".$end,str2url(basename($files[$ki]['name'])));
				if (basename($files[$ki]['name'])) 	{
					move_uploaded_file($files[$ki]['tmp_name'] , $uploadfile);
					$post[$ki] = $uploadfile;
				} 	
			}
		}
			$table = $post['table'];
			$id = $post['id'];
			unset($post['Submit'],$post['action'],$post['table'],$post['id'], $post['imagename']);
			$values = "'".implode("','",array_values($post))."'";
			$keys = implode(",",array_keys($post));
			$sql = "INSERT INTO news (".$keys.") VALUES (".$values.")";
			$result = getMysqliResult($sql);
			index();
	}
	
	function delete()	{
		$id = 		$_GET['id'];
		$sql = "DELETE FROM news WHERE id=".$id;
		$result = getMysqliResult($sql);
		index();
	}
	
     // Добавления записи (форма)
    function insertform(){
		updateform();
	}

