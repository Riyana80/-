<?php
	// Функция вывода всех записей в панель
    function index(){
?>
		<h1>Отзывы</h1>
<?php
		$sql = "SELECT `id`,`content`,`date`,(SELECT CONCAT(`lastname`,' ',`firstname`,' ',`fname`) FROM `user` WHERE `user`.`id` = user_id) AS user_id,(SELECT `name` FROM `product` WHERE `product`.`id` = product_id) AS product_id,(SELECT `name` FROM `rating` WHERE `rating`.`id` = rating_id) AS rating_id FROM `request` WHERE 1 ORDER BY id";
		$result = getMysqliResult($sql);
		if($result->num_rows > 0)	{
?>
		<table class="shadow-lg">
			<tr><th></th>
				<th>Номер</th>
				<th>Дата</th>
				<th>Пользователь</th>
				<th>Товар</th>
				<th style="width:500px;">Содержимое отзыва</th>
				<th>Рейтинг</th>
			</tr>
<?php	
			$i = 0;
			while ($item = $result->fetch_assoc()) {
				$i++;
				?>
				<tr>
					<td>
						<!-- Кнопки удаления и редактирования -->
						<a  onclick='return confirm("Удалить отзыв?");' href='?table=request&action=delete&id=<?php echo $item['id']; ?>'><img src='images/del.png'></a>
						<!-------------------------------------->
					</td>
					<td class='text-center'><?php echo $item['id']; ?></td>
					<td class='text-right' ><?php echo date('d/m/Y', strtotime($item['date'])); ?></td>
					<td class='text-center'><?php echo $item['user_id']; ?></td>
					<td class='text-center'><?php echo $item['product_id']; ?></td>
					<td class='text-center'><?php echo $item['content']; ?></td>
					<td class='text-center'><?php echo $item['rating_id']; ?></td>
				</tr>
<?php	
			}
?>		</table>
<?php
		}
	}

 	// Функция обновляет запись в таблице
 	function update()	{
		$post = $_POST;
		
		$table = $post['table'];
		$id = $post['id'];
		unset($post['Submit'],$post['action'],$post['table'],$post['id']);
		$values = array();
		
		foreach($post as $key=>$val) $values[] = $key." = '".$val."'";	
		$sql = "UPDATE request SET ".implode(",",$values)." WHERE id=".$id;
		$result = getMysqliResult($sql);
		index();
	}

	// Функция удаляет запись из таблицы
	function delete($id)	{
		$sql = "DELETE FROM request WHERE id=".$id;
		$result = getMysqliResult($sql);
		index();
	}
	
