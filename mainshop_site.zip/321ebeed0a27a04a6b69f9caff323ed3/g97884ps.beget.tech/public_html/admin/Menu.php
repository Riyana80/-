<?php
	// Вывод всех записей в панель
    function index(){
		?>
			<script>
				function confirmSpelll() {
				if (confirm("Вы действительно хотите удалить этот элемент?")) return true;
				else return false;
				}
			</script>
		<h1>Меню</h1>
		<center><a href='?table=menu&action=insertform'>Добавить новый</a></center>
		<table>
			<tr>
				<th></th>
				<th>Номер</th>
				<th>Наименование</th>
				<th>Логин страницы (латинскими буквами)</th>
			</tr>
		<?php
		$sql = "SELECT * FROM menu WHERE 1 ORDER BY id";
		$result = getMysqliResult($sql);
		if($result)	while ($menu = $result->fetch_assoc()) {
				?> 
					<tr>
						<td style='width:70px;'>
							<a  onclick='return confirmSpelll();' href='?table=menu&action=delete&id=<?php echo $menu['id']; ?>'><img src='images/del.png'></a>&nbsp;&nbsp;
							<a href='?table=menu&action=updateform&id=<?php echo $menu['id']; ?>'><img src='images/edit.png'></a>
						</td>
						<td><?php echo $menu['id']; ?>	</td>
						<td><?php echo $menu['name']; ?>	</td>
						<td><?php echo $menu['url']; ?>	</td>
					</tr>
				<?php	
			}
		echo "</table>";
    }

    // Обновления записи (форма)
     function updateform($id = NULL){
		if(!empty($id))	{
			$sql = "SELECT * FROM menu WHERE id=".$id." ORDER BY id";
			$result = getMysqliResult($sql);
		if($result)
			$menu = $result->fetch_assoc();
		}
		else {
			$fields = "id,name,image,url,content";
			foreach(explode(",",$fields) as $f) $menu[$f] = '';
		}
		if(!empty($id)) echo "<h1 class='text-center top' >Редактирование записи № ".$id." в таблице Меню</h1></center>".PHP_EOL;
		else echo "<center><h1  class='text-center top' >Добавление записи в таблицу Меню</h1></center>".PHP_EOL;
		echo "<div class='row'>".PHP_EOL;
		echo '	<div class="col-xs-1 col-sm-3 col-md-4 col-lg-4"></div>'.PHP_EOL;
		echo '	<div class="p-3 col-xs-10 col-sm-6 col-md-4 col-lg-4" style="margin:10px auto 20px auto; padding:5px 10px; border:1px solid #ddd; border-radius:10px;">'.PHP_EOL;
		echo '		<div style="position:relative;width:100%; text-align:right; float:right;right:-13px;">'.PHP_EOL;
		echo '			<a href="admin.php"><span style="color:grey; font-size:20px" class="btnicon icon-close"></span></a>'.PHP_EOL;
		echo '		</div>'.PHP_EOL;
		echo "		<form enctype='multipart/form-data' action='?table=menu' method='post'>".PHP_EOL;
		echo "			<input type='hidden' name='id' value = '".$id."'>".PHP_EOL;
		?>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Наименование <span class='text-red font-weight-bold'>*</span></label>
			<div>
				<input class='form-control' id='name' name='name'  required = "true" type='text' value='<?php echo $menu['name']; ?>'/>
			</div>
		</div>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Логин страницы <span class='text-red font-weight-bold'>*</span></label>
			<div>
				<input class='form-control' id='url'  required = "true" name='url' type='text' value='<?php echo $menu['url']; ?>'/>
			</div>
		</div>
		<div class='form-group'>
			<label style='word-wrap: break-word;'>Содержимое</label>
			<div>
				<textarea class='form-control' cols="80" rows="5" id='content' name='content'/><?php echo file_get_contents("include/".$menu['url'].".php"); ?></textarea>
			</div>
		</div>
<?php
		if(!empty($id)) echo "			<input type='hidden' name='action' value = 'update'>".PHP_EOL;
		else echo "			<input type='hidden' name='action' value = 'insert'>".PHP_EOL;
		echo "			<input type='hidden' name='table' value = 'menu'>".PHP_EOL;
		if(!empty($id)) echo '			<div class="text-center"><input class="submit" id="Submit" value="Сохранить изменения" type="submit" name="Submit" ></div>'.PHP_EOL;
		else echo '			<div class="text-center"><input class="submit" id="Submit" value="Добавить" type="submit" name="Submit" ></div>'.PHP_EOL;
		echo "			<hr><span class='text-red font-weight-bold'>*</span> - обязательные для заполнения поля";
		echo "		</form>".PHP_EOL;
		echo "	</div>".PHP_EOL;
		echo "</div>".PHP_EOL;
	}

// Обновление записи
 	function update()	{
		$post = $_POST;
		$url = $post['url'];
		$content = $post['content'];
		$table = $post['table'];
		$id = $post['id'];
		unset($post['Submit'],$post['action'],$post['table'],$post['id'],$post['content']);
		$values = array();
		foreach($post as $key=>$val) $values[] = $key." = '".$val."'";
		$sql = "UPDATE menu SET ".implode(",",$values)." WHERE id=".$id;
		$result = getMysqliResult($sql);
		file_put_contents("include/".$url.".php",$content);
		index();
	}

// Добавление записи
 	function insert()	{
		$post = $_POST;
		$table = $post['table'];
		$id = $post['id'];
		$url = $post['url'];
		$content = $post['content'];
		unset($post['Submit'],$post['action'],$post['table'],$post['id'],$post['content']);
		$values = "'".implode("','",array_values($post))."'";
		$keys = implode(",",array_keys($post));
		$sql = "INSERT INTO menu (".$keys.") VALUES (".$values.")";
		pr($sql);
		$result = getMysqliResult($sql);
		file_put_contents("include/".$url.".php",$content);
		index();
	}
	
	function delete()	{
		$id = 		$_GET['id'];
		$sql = "DELETE FROM menu WHERE id=".$id;
		$result = getMysqliResult($sql);
		index();
	}
	
     // Добавления записи (форма)
    function insertform(){
		updateform();
	}

