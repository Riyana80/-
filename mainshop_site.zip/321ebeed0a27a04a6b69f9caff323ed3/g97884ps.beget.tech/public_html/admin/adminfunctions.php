<?php
function left($str = "", $count)		{
	return substr($str, 0, $count);
}

function right($str = "", $count)		{
	return substr($str, $count*-1);
}

function pr($value)	{				// Функция для вывода массива или значения
	echo "<pre>";
	if(gettype($value) == 'array')	print_r($value); else { echo ($value); echo "<hr>"; }
	echo "</pre>";
}

function is_sel($a, $b)	{
  if((gettype($b) == "array")&&(in_array($a,$b)))  return 'selected="selected"';	
  elseif($a == $b) return 'selected="selected"';
  elseif(in_array($a,explode(",",$b))) return 'selected="selected"';
  else return '';
}

function is_sel_arr($a, $b)
{
  if(in_array($a, explode(',', $b))) return 'selected="selected"';
}

function rus2translit($string) {
    $converter = array(
        'а' => 'a',   'б' => 'b',   'в' => 'v',
        'г' => 'g',   'д' => 'd',   'е' => 'e',
        'ё' => 'e',   'ж' => 'zh',  'з' => 'z',
        'и' => 'i',   'й' => 'y',   'к' => 'k',
        'л' => 'l',   'м' => 'm',   'н' => 'n',
        'о' => 'o',   'п' => 'p',   'р' => 'r',
        'с' => 's',   'т' => 't',   'у' => 'u',
        'ф' => 'f',   'х' => 'h',   'ц' => 'c',
        'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',
        'ь' => '\'',  'ы' => 'y',   'ъ' => '\'',
        'э' => 'e',   'ю' => 'yu',  'я' => 'ya',
        
        'А' => 'A',   'Б' => 'B',   'В' => 'V',
        'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
        'Ё' => 'E',   'Ж' => 'Zh',  'З' => 'Z',
        'И' => 'I',   'Й' => 'Y',   'К' => 'K',
        'Л' => 'L',   'М' => 'M',   'Н' => 'N',
        'О' => 'O',   'П' => 'P',   'Р' => 'R',
        'С' => 'S',   'Т' => 'T',   'У' => 'U',
        'Ф' => 'F',   'Х' => 'H',   'Ц' => 'C',
        'Ч' => 'Ch',  'Ш' => 'Sh',  'Щ' => 'Sch',
        'Ь' => '\'',  'Ы' => 'Y',   'Ъ' => '\'',
        'Э' => 'E',   'Ю' => 'Yu',  'Я' => 'Ya',
    );
    return strtr($string, $converter);
}
function str2url($str) {
    // переводим в транслит
    $str = rus2translit($str);
    // в нижний регистр
    $str = strtolower($str);
    // заменям все ненужное нам на "-"
    $str = preg_replace('~[^-a-z0-9_]+~u', '-', $str);
    // удаляем начальные и конечные '-'
    $str = trim($str, "-");
    return $str;
}

function getPathCategory($id)	{
	$bc = array();
			$sql = "SELECT id, name, parent_id FROM category WHERE id=$id";
			$result = getMysqliResult($sql);
			if($result)	{
				$myrow = $result->fetch_assoc();
				$bc['self'] = $myrow['name'];
				$id = $myrow['id'];
			}	
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$myrow['parent_id'];
			$result = getMysqliResult($sql);
			if($result)	{
				$myrow = $result->fetch_assoc();
				$bc['parent3'] 	= $myrow['name'];
				$id = $myrow['id'];
			}
		}	
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$myrow['parent_id'];
			$result = getMysqliResult($sql);
			if($result)	{
				$myrow = $result->fetch_assoc();
				$bc['parent2'] 	= $myrow['name'];
				$id = $myrow['id'];
			}
		}	
		if($id<>1)	{
			$sql = "SELECT id, name, parent_id FROM category WHERE id=".$myrow['parent_id'];
			$result = getMysqliResult($sql);
			if($result)	{
				$myrow = $result->fetch_assoc();
				$bc['parent1'] 	= $myrow['name'];
				$id = $myrow['id'];
			}
		}
	$str  = (!empty($bc['parent1']))?$bc['parent1']." -> ":"";	
	$str .= (!empty($bc['parent2']))?$bc['parent2']." -> ":"";	
	$str .= (!empty($bc['parent3']))?$bc['parent3']." -> ":"";	
	$str .= (!empty($bc['self']))?$bc['self']:"";	
	return str_replace("Каталог -> ","",$str);
}


?>